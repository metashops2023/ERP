<?php

namespace App\Http\Controllers;

use App\Models\AdminUserBranch;
use App\Models\Branch;
use Illuminate\Http\Request;
use App\Models\CustomerGroup;
use Illuminate\Support\Facades\DB;

class CustomerGroupController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin_and_user');
    }

    // Customer main page/index page
    public function index()
    {
        $branches = getUserBranches();
        return view('contacts.customer_group.index', compact('branches'));
    }

    // Get all customer group by ajax
    public function allBanks()
    {
        $branches = getUserBranches();

        if (auth()->user()->role_type == 1) {
            $groups = CustomerGroup::orderBy('id', 'DESC')->get();
        } else if (auth()->user()->role_type == 2) {
            $groups = CustomerGroup::where('admin_user_id', auth()->user()->id)->orderBy('id', 'DESC')->get();
        } else {
            $groups = CustomerGroup::where('branch_id', auth()->user()->branch_id)->orderBy('id', 'DESC')->get();
        }
        // $groups = CustomerGroup::orderBy('id', 'DESC')->get();
        return view('contacts.customer_group.ajax_view.group_list', compact('groups', 'branches'));
    }

    // Store customer group
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'add_branch_id' => 'required',
        ]);

        $branchUser = getBranchUser($request->add_branch_id);

        CustomerGroup::insert([
            'group_name' => $request->name,
            'admin_user_id' => $branchUser->id,
            'branch_id' => $request->add_branch_id,
            'calc_percentage' => $request->calculation_percent ? $request->calculation_percent : 0.00,
        ]);
        return response()->json('Customer group created successfully');
    }

    // Update customer group
    public function update(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
        ]);

        $updateBank = CustomerGroup::where('id', $request->id)->first();
        $updateBank->update([
            'group_name' => $request->name,
            'calc_percentage' => $request->calculation_percent ? $request->calculation_percent : 0.00,
        ]);
        return response()->json(' Customer group updated successfully');
    }

    // delete customer group
    public function delete(Request $request, $groupId)
    {
        $deleteCustomerGroup = CustomerGroup::find($groupId);
        if (!is_null($deleteCustomerGroup)) {
            $deleteCustomerGroup->delete();
        }
        return response()->json('Customer group deleted successfully');
    }
}
