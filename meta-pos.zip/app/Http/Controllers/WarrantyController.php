<?php

namespace App\Http\Controllers;

use App\Models\AdminUserBranch;
use App\Models\Branch;
use App\Models\Warranty;
use Illuminate\Http\Request;
use App\Utils\UserActivityLogUtil;
use Illuminate\Support\Facades\DB;

class WarrantyController extends Controller
{
    protected $userActivityLogUtil;
    public function __construct(UserActivityLogUtil $userActivityLogUtil)
    {
        $this->userActivityLogUtil = $userActivityLogUtil;
        $this->middleware('auth:admin_and_user');
    }
    // Warranty main page/index page
    public function index()
    {
        if (auth()->user()->permission->product['warranties'] == '0') {

            abort(403, 'Access Forbidden.');
        }

        if (auth()->user()->role_type == 1) {
            $branches = DB::table('branches')->get(['id', 'name', 'branch_code']);
        } else if (auth()->user()->role_type == 2) {
            $branchIds = AdminUserBranch::select("branch_id")->where('admin_user_id', auth()->user()->id)->get()->toArray();
            $branches = DB::table('branches')->whereIn('id', $branchIds)->get(['id', 'name', 'branch_code']);
        } else {
            $branches = Branch::where('id', auth()->user()->branch_id)->get(['id', 'name', 'branch_code']);
        }

        return view('product.warranties.index', compact('branches'));
    }

    // Get all warranty by ajax
    public function allWarranty()
    {
        if (auth()->user()->role_type == 1) {
            $warranties = Warranty::orderBy('id', 'DESC')->get();
        } else if (auth()->user()->role_type == 2) {
            $warranties = DB::table('warranties')
                ->where('admin_user_id', auth()->user()->id)
                ->orderBy('id', 'DESC')->get();
        } else {
            $warranties = DB::table('warranties')
                ->where('branch_id', auth()->user()->branch_id)
                ->orderBy('id', 'DESC')->get();
        }
        // $warranties = Warranty::orderBy('id', 'DESC')->get();
        return view('product.warranties.ajax_view.warranty_list', compact('warranties'));
    }

    // Store warranty
    public function store(Request $request)
    {
        if (auth()->user()->permission->product['warranties'] == '0') {

            return response()->json('Access Denied');
        }

        $this->validate($request, [
            'name' => 'required',
            'duration' => 'required',
            'add_branch_id' => 'required',
        ]);
        $branchUser = getBranchUser($request->add_branch_id);
        $addWarranty = Warranty::create([
            'admin_user_id' => $branchUser->id,
            'branch_id' => $request->add_branch_id,
            'name' => $request->name,
            'type' => $request->type,
            'duration' => $request->duration,
            'duration_type' => $request->duration_type,
            'description' => $request->description,
        ]);

        if ($addWarranty) {

            $this->userActivityLogUtil->addLog(action: 1, subject_type: 25, data_obj: $addWarranty);
        }

        return response()->json('Warranty is created Successfully');
    }

    // Update warranty
    public function update(Request $request)
    {
        if (auth()->user()->permission->product['warranties'] == '0') {

            return response()->json('Access Denied');
        }

        $branchUser = getBranchUser($request->update_branch_id);

        $this->validate($request, [
            'admin_user_id' => $branchUser->id,
            'branch_id' => $request->update_branch_id,
            'name' => 'required',
            'duration' => 'required',
            'update_branch_id' => 'required',
        ]);

        $updateWarranty = Warranty::where('id', $request->id)->first();

        $updateWarranty->update([
            'admin_user_id' => $branchUser->id,
            'branch_id' => $request->update_branch_id,
            'name' => $request->name,
            'type' => $request->type,
            'duration' => $request->duration,
            'duration_type' => $request->duration_type,
            'description' => $request->description,
        ]);

        if ($updateWarranty) {

            $this->userActivityLogUtil->addLog(action: 2, subject_type: 25, data_obj: $updateWarranty);
        }

        return response()->json('Warranty updated successfully');
    }

    // Delete warranty
    public function delete(Request $request, $warrantyId)
    {
        if (auth()->user()->permission->product['warranties'] == '0') {

            return response()->json('Access Denied');
        }
        $deleteWarranty = Warranty::find($warrantyId);

        if (!is_null($deleteWarranty)) {

            $this->userActivityLogUtil->addLog(action: 3, subject_type: 25, data_obj: $deleteWarranty);

            $deleteWarranty->delete();
        }
        return response()->json('Warranty deleted successfully');
    }
}
