<?php

namespace App\Http\Controllers;

use App\Models\AdminUserBranch;
use App\Models\Branch;
use App\Models\Tax;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TaxController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin_and_user');
    }

    public function index()
    {
        if (auth()->user()->permission->setup['tax'] == '0') {
            abort(403, 'Access Forbidden.');
        }
        if (auth()->user()->role_type == 1) {
            $branches = DB::table('branches')->get(['id', 'name', 'branch_code']);
        } else if (auth()->user()->role_type == 2) {
            $branchIds = AdminUserBranch::select("branch_id")->where('admin_user_id', auth()->user()->id)->get()->toArray();
            $branches = DB::table('branches')->whereIn('id', $branchIds)->get(['id', 'name', 'branch_code']);
        } else {
            $branches = Branch::where('id', auth()->user()->branch_id)->get(['id', 'name', 'branch_code']);
        }
        return view('settings.taxes.index', compact('branches'));
    }

    public function getAllVat()
    {
        if (auth()->user()->role_type == 1) {
            $taxes = Tax::all();
        } else if (auth()->user()->role_type == 2) {
            $taxes = DB::table('taxes')
                ->where('admin_user_id', auth()->user()->id)
                ->orderBy('id', 'DESC')->get();
        } else {
            $taxes = DB::table('taxes')
                ->where('branch_id', auth()->user()->branch_id)
                ->orderBy('id', 'DESC')->get();
        }
        // $taxes = Tax::all();
        return view('settings.taxes.ajax_view.tax_list', compact('taxes'));
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'tax_name' => 'required',
            'tax_percent' => 'required',
            'add_branch_id' => 'required',
        ]);
        $branchUser = getBranchUser($request->add_branch_id);

        $addTax = new Tax();
        $addTax->tax_name = $request->tax_name;
        $addTax->tax_percent = $request->tax_percent;
        $addTax->admin_user_id = $branchUser->id;
        $addTax->branch_id = $request->add_branch_id;
        $addTax->save();
        return response()->json('Tax added successfully');
    }

    public function update(Request $request)
    {
        $this->validate($request, [
            'tax_name' => 'required',
            'tax_percent' => 'required',
            'update_branch_id' => 'required',
        ]);
        $branchUser = getBranchUser($request->update_branch_id);

        $updateTax = Tax::where('id', $request->id)->first();
        $updateTax->tax_name = $request->tax_name;
        $updateTax->tax_percent = $request->tax_percent;
        $updateTax->admin_user_id = $branchUser->id;
        $updateTax->branch_id = $request->update_branch_id;
        $updateTax->save();
        return response()->json('Tax updated successfully');
    }

    public function delete(Request $request, $taxId)
    {
        $deleteVat = Tax::where('id', $taxId)->first();
        if (!is_null($deleteVat)) {
            $deleteVat->delete();
        }
        return response()->json('Tax deleted successfully');
    }
}
