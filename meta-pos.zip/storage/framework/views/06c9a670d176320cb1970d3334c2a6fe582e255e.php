<?php
   use Illuminate\Support\Str;
?>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($product->is_variant == 1): ?>
            <?php
                $tax_percent = $product->tax_percent ? $product->tax_percent : 0;
                $tax_amount = $product->variant_price / 100 * $tax_percent;
            ?>
            <div class="col-4 p-1">
                <a href="#" tabindex="-1" title="<?php echo e($product->name.' - '.$product->variant_name); ?>" href="#" class="select_variant_product" data-p_id="<?php echo e($product->id); ?>" data-v_id="<?php echo e($product->variant_id); ?>" data-p_name="<?php echo e($product->name); ?>" data-p_tax_id="<?php echo e($product->tax_id); ?>" data-unit="<?php echo e($product->unit_name); ?>" data-tax_percent="<?php echo e($tax_percent); ?>" data-tax_type="<?php echo e($product->tax_type); ?>" data-tax_amount="<?php echo e(bcadd($tax_amount, 0, 2)); ?>" data-v_code="<?php echo e($product->variant_code); ?>" data-description="<?php echo e($product->is_show_emi_on_pos); ?>" data-v_price="<?php echo e($product->variant_price); ?>" data-v_name="<?php echo e($product->variant_name); ?>" data-v_cost_inc_tax="<?php echo e($product->variant_cost_with_tax); ?>" onclick="salectVariant(this); return false;">
                    <div class="product">
                        <div class="product-img">
                            <img loading="lazy" src="<?php echo e(asset('uploads/product/thumbnail/'.$product->thumbnail_photo)); ?>">
                        </div>
                        <div class="product-name" id="<?php echo e($product->id.$product->variant_id); ?>">
                            <a href="#" tabindex="-1">
                                <?php echo e(Str::limit($product->name.' - '.$product->variant_name, 15, '')); ?>

                            </a>
                        </div>
                    </div>
                </a>
            </div>
        <?php else: ?>
            <?php
                $tax_percent = $product->tax_percent ? $product->tax_percent : 0.00;
                $tax_amount = $product->product_price / 100 * $tax_percent;
            ?>
            <div class="col-4 p-1">
                <a href="#" tabindex="-1" title="<?php echo e($product->name); ?>" href="#" class="select_single_product" data-p_id="<?php echo e($product->id); ?>" data-p_name="<?php echo e($product->name); ?>" data-p_tax_id="<?php echo e($product->tax_id); ?>" data-p_code="<?php echo e($product->product_code); ?>" data-unit="<?php echo e($product->unit_name); ?>" data-p_tax_percent="<?php echo e($tax_percent); ?>" data-tax_type="<?php echo e($product->tax_type); ?>" data-p_tax_amount="<?php echo e(bcadd((float) $tax_amount, 0, 2)); ?>" data-description="<?php echo e($product->is_show_emi_on_pos); ?>" data-p_price_exc_tax="<?php echo e($product->product_price); ?>" data-p_cost_inc_tax="<?php echo e($product->product_cost_with_tax); ?>" onclick="singleProduct(this); return false;">
                    <div class="product">
                        <div class="product-img">
                            <img loading="lazy" src="<?php echo e(asset('uploads/product/thumbnail/'.$product->thumbnail_photo)); ?>">
                        </div>
                        <div class="product-name" id="<?php echo e($product->id.'noid'); ?>">
                            <a href="#" tabindex="-1">
                                <?php echo e(Str::limit($product->name, 15, '')); ?>

                            </a>
                        </div>
                    </div>
                </a>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





<?php /**PATH C:\Bileet\Meta\meta-pos\resources\views/sales/pos/ajax_view/select_product_list.blade.php ENDPATH**/ ?>