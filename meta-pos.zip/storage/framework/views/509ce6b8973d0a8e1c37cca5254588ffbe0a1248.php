<?php
    $defaultLayout = DB::table('invoice_layouts')->where('is_default', 1)->first();
?>
<?php if($defaultLayout->layout_design == 1): ?>
    <div class="sale_print_template">
        <style>
            @page  {size:a4;margin-top: 0.8cm;/* margin-bottom: 35px;  */margin-left: 4%;margin-right: 4%;}
            div#footer {position:fixed;bottom:25px;left:0px;width:100%;height:0%;color:#CCC;background:#333; padding: 0; margin: 0;}
        </style>
        <div class="details_area">
            <?php if($defaultLayout->is_header_less == 0): ?>
                <div id="header">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="header_text text-center">
                                <p><?php echo e($defaultLayout->header_text); ?></p>
                                <p><?php echo e($defaultLayout->sub_heading_1); ?></p>
                                <p><?php echo e($defaultLayout->sub_heading_2); ?></p>
                                <p><?php echo e($defaultLayout->sub_heading_3); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <?php if($defaultLayout->show_shop_logo == 1): ?>
                                <?php if($sale->branch): ?>
                                    <?php if($sale->branch->logo != 'default.png'): ?>
                                        <img style="height: 40px; width:200px;" src="<?php echo e(asset('public/uploads/branch_logo/' . $sale->branch->logo)); ?>">
                                    <?php else: ?>
                                        <span style="font-family: 'Anton', sans-serif;font-size:17px;color:gray;font-weight: 550; letter-spacing:1px;"><?php echo e($sale->branch->name); ?></span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if(json_decode($generalSettings->business, true)['business_logo'] != null): ?>
                                        <img style="height: 40px; width:200px;" src="<?php echo e(asset('public/uploads/business_logo/' . json_decode($generalSettings->business, true)['business_logo'])); ?>" alt="logo" class="logo__img">
                                    <?php else: ?>
                                        <span style="font-family: 'Anton', sans-serif;font-size:17px;color:gray;font-weight: 550; letter-spacing:1px;"><?php echo e(json_decode($generalSettings->business, true)['shop_name']); ?></span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <div class="col-8">
                            <div class="heading text-end">
                                <?php if($sale->branch): ?>
                                    <p class="company_name" style="text-transform: uppercase;">
                                        <strong><?php echo e($sale->branch->name); ?></strong>
                                    </p>

                                    <p class="company_address">
                                        <?php echo e($defaultLayout->branch_city == 1 ? $sale->branch->city : ''); ?>,
                                        <?php echo e($defaultLayout->branch_state == 1 ? $sale->branch->state : ''); ?>,
                                        <?php echo e($defaultLayout->branch_zipcode == 1 ? $sale->branch->zip_code : ''); ?>,
                                        <?php echo e($defaultLayout->branch_country == 1 ? $sale->branch->country : ''); ?>.
                                    </p>

                                    <?php if($defaultLayout->branch_phone): ?>
                                        <p><b><?php echo app('translator')->get('Phone'); ?> :</b>  <?php echo e($sale->branch->phone); ?></p>
                                    <?php endif; ?>

                                    <?php if($defaultLayout->branch_email): ?>
                                        <p><b><?php echo app('translator')->get('Email'); ?> :</b> <?php echo e($sale->branch->email); ?></p>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <p class="company_name" style="text-transform: uppercase;">
                                        <strong><?php echo e(json_decode($generalSettings->business, true)['shop_name']); ?></strong>
                                    </p>

                                    <p class="company_address">
                                        <?php echo e(json_decode($generalSettings->business, true)['address']); ?>

                                    </p>

                                    <?php if($defaultLayout->branch_phone): ?>
                                        <p><strong><?php echo app('translator')->get('Phone'); ?> :</strong> <?php echo e(json_decode($generalSettings->business, true)['phone']); ?></p>
                                    <?php endif; ?>

                                    <?php if($defaultLayout->branch_email && json_decode($generalSettings->business, true)['email']): ?>
                                        <p><strong><?php echo app('translator')->get('Email'); ?> :</strong> <?php echo e(json_decode($generalSettings->business, true)['email']); ?></p>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="middle_header_text text-center">
                                <h5><?php echo e($defaultLayout->invoice_heading); ?></h5>
                                <h6>
                                    <?php
                                        $payable = $sale->total_payable_amount - $sale->sale_return_amount;
                                    ?>

                                    <?php if($sale->due <= 0): ?>
                                        Paid
                                    <?php elseif($sale->due > 0 && $sale->due < $payable): ?>
                                        Partial
                                    <?php elseif($payable==$sale->due): ?>
                                        Due
                                    <?php endif; ?>
                                </h6>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if($defaultLayout->is_header_less == 1): ?>
                <?php for($i = 0; $i < $defaultLayout->gap_from_top; $i++): ?>
                    <br/>
                <?php endfor; ?>
            <?php endif; ?>

            <div class="purchase_and_deal_info pt-3">
                <div class="row">
                    <div class="col-lg-4">
                        <ul class="list-unstyled">
                            <li><strong><?php echo app('translator')->get('Customer'); ?> : </strong>
                                <?php echo e($sale->customer ? $sale->customer->name : 'Walk-In-Customer'); ?>

                            </li>
                            <?php if($defaultLayout->customer_address): ?>
                                <li><strong><?php echo app('translator')->get('Address'); ?> : </strong>
                                    <?php echo e($sale->customer ? $sale->customer->address : ''); ?>

                                </li>
                            <?php endif; ?>

                            <?php if($defaultLayout->customer_tax_no): ?>
                                <li><strong><?php echo app('translator')->get('Tax Number'); ?> : </strong>
                                    <?php echo e($sale->customer ? $sale->customer->tax_number : ''); ?>

                                </li>
                            <?php endif; ?>

                            <?php if($defaultLayout->customer_phone): ?>
                                <li><strong><?php echo app('translator')->get('Phone'); ?> : </strong> <?php echo e($sale->customer ? $sale->customer->phone : ''); ?></li>
                            <?php endif; ?>

                            <?php if(json_decode($generalSettings->reward_poing_settings, true)['enable_cus_point'] == 1): ?>
                                <li><strong><?php echo e(json_decode($generalSettings->reward_poing_settings, true)['point_display_name']); ?> : </strong>
                                    <?php echo e($sale->customer ? $sale->customer->point : 0); ?>

                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>

                    <div class="col-lg-4 text-center">
                        <?php if($defaultLayout->is_header_less == 1): ?>
                            <div class="middle_header_text text-center">
                                <h5><?php echo e($defaultLayout->invoice_heading); ?></h5>
                                <h6>
                                    <?php
                                        $payable = $sale->total_payable_amount - $sale->sale_return_amount;
                                    ?>

                                    <?php if($sale->due <= 0): ?>
                                        Paid
                                    <?php elseif($sale->due > 0 && $sale->due < $payable): ?>
                                        Partial
                                    <?php elseif($payable==$sale->due): ?>
                                        Due
                                    <?php endif; ?>
                                </h6>
                            </div>
                        <?php endif; ?>
                        <img style="width: 170px; height:35px; margin-top:3px;" src="data:image/png;base64,<?php echo e(base64_encode($generator->getBarcode($sale->invoice_id, $generator::TYPE_CODE_128))); ?>">
                    </div>
                    <div class="col-lg-4">
                        <ul class="list-unstyled">
                            <li><strong> <?php echo app('translator')->get('Invoice No'); ?> : </strong> <?php echo e($sale->invoice_id); ?></li>
                            <li><strong> <?php echo app('translator')->get('Date'); ?> : </strong> <?php echo e(date(json_decode($generalSettings->business, true)['date_format'] ,strtotime($sale->date)) . ' ' . date($timeFormat, strtotime($sale->time))); ?></li>
                            <li><strong> <?php echo app('translator')->get('Entered By'); ?> : </strong> <?php echo e($sale->admin ? $sale->admin->prefix . ' ' . $sale->admin->name . ' ' . $sale->admin->last_name : 'N/A'); ?></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="sale_product_table pt-3 pb-3">
                <table class="table modal-table table-sm table-bordered">
                    <thead>
                        <tr>
                            <th class="text-start">SL</th>
                            <th class="text-start"><?php echo app('translator')->get('Descrpiton'); ?></th>
                            <th class="text-start"><?php echo app('translator')->get('Sold Qty'); ?></th>
                            <?php if($defaultLayout->product_w_type || $defaultLayout->product_w_duration || $defaultLayout->product_w_discription): ?>
                                <th class="text-start"><?php echo app('translator')->get('Warranty'); ?></th>
                            <?php endif; ?>
                            <th class="text-start"><?php echo app('translator')->get('Price'); ?></th>
                            <?php if($defaultLayout->product_discount): ?>
                                <th class="text-start"><?php echo app('translator')->get('Discount'); ?></th>
                            <?php endif; ?>

                            <?php if($defaultLayout->product_tax): ?>
                                <th class="text-start"><?php echo app('translator')->get('Tax'); ?></th>
                            <?php endif; ?>
                            <th class="text-start"><?php echo app('translator')->get('SubTotal'); ?></th>
                        </tr>
                    </thead>
                    <tbody class="sale_print_product_list">
                        <?php $__currentLoopData = $sale->sale_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-start"><?php echo e($loop->index + 1); ?></td>
                                <td class="text-start">
                                    <?php echo e($sale_product->product->name); ?>

                                    <?php if($sale_product->variant): ?>
                                        -<?php echo e($sale_product->variant->variant_name); ?><?php echo $sale_product->ex_quantity != 0 ? '(<b>EX:</b>'.$sale_product->ex_quantity.')' : ''; ?>

                                    <?php endif; ?>
                                    <?php echo $defaultLayout->product_imei == 1 ? '<br><small class="text-muted">' . $sale_product->description . '</small>' : ''; ?>

                                </td>
                                <td class="text-start"><?php echo e($sale_product->quantity); ?>(<?php echo e($sale_product->unit); ?>) </td>

                                <?php if($defaultLayout->product_w_type || $defaultLayout->product_w_duration || $defaultLayout->product_w_discription): ?>
                                    <td class="text-start">
                                        <?php if($sale_product->product->warranty): ?>
                                            <?php echo e($sale_product->product->warranty->duration . ' ' . $sale_product->product->warranty->duration_type); ?>

                                            <?php echo e($sale_product->product->warranty->type == 1 ? 'Warranty' : 'Guaranty'); ?>

                                            <?php echo $defaultLayout->product_w_discription ? '<br><small class="text-muted">' . $sale_product->product->warranty->description . '</small>' : ''; ?>

                                        <?php else: ?>
                                            <b>No</b>
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>

                                <td class="text-start"><?php echo e(App\Utils\Converter::format_in_bdt($sale_product->unit_price_inc_tax)); ?> </td>

                                <?php if($defaultLayout->product_discount): ?>
                                    <td class="text-start">
                                        <?php echo e(App\Utils\Converter::format_in_bdt($sale_product->unit_discount_amount)); ?>

                                    </td>
                                <?php endif; ?>

                                <?php if($defaultLayout->product_tax): ?>
                                    <td class="text-start">
                                        <?php echo e($sale_product->unit_tax_percent); ?>%
                                    </td>
                                <?php endif; ?>

                                <td class="text-start">
                                    <?php echo e(App\Utils\Converter::format_in_bdt($sale_product->subtotal)); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php if(count($sale->sale_products) > 15): ?>
                <br>
                <div class="row page_break">
                    <div class="col-md-12 text-end">
                        <h6><em><?php echo app('translator')->get('Continued To this next page'); ?>....</em></h6>
                    </div>
                </div>
                <?php if($defaultLayout->is_header_less == 1): ?>
                    <?php for($i = 0; $i < $defaultLayout->gap_from_top; $i++): ?>
                        <br/>
                    <?php endfor; ?>
                <?php endif; ?>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-6">
                    <?php if($defaultLayout->show_total_in_word == 1): ?>
                        <p style="text-transform: uppercase;"><b><?php echo app('translator')->get('In Word'); ?> : </b> <span id="inword"></span> <?php echo app('translator')->get('ONLY'); ?>.</p>
                    <?php endif; ?>

                    <?php if(
                        $defaultLayout->account_name ||
                        $defaultLayout->account_no ||
                        $defaultLayout->bank_name ||
                        $defaultLayout->bank_branch
                      ): ?>
                        <div class="bank_details" style="width:100%; border:1px solid black;padding:2px 3px;">
                            <?php if($defaultLayout->account_name): ?>
                                <p><?php echo app('translator')->get('Account Name'); ?> : <?php echo e($defaultLayout->account_name); ?></p>
                            <?php endif; ?>

                            <?php if($defaultLayout->account_no): ?>
                                <p><?php echo app('translator')->get('Account No'); ?> : <?php echo e($defaultLayout->account_no); ?></p>
                            <?php endif; ?>

                            <?php if($defaultLayout->bank_name): ?>
                                <p><?php echo app('translator')->get('Bank'); ?> : <?php echo e($defaultLayout->bank_name); ?></p>
                            <?php endif; ?>

                            <?php if($defaultLayout->bank_branch): ?>
                                <p><?php echo app('translator')->get('Branch'); ?> : <?php echo e($defaultLayout->bank_branch); ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <table class="table modal-table table-sm">
                        <tbody>
                            <tr>
                                <td class="text-end"><strong><?php echo app('translator')->get('Net Total Amount'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?></strong></td>
                                <td class="net_total text-end"><?php echo e(App\Utils\Converter::format_in_bdt($sale->net_total_amount)); ?></td>
                            </tr>
                            <tr>
                                <td class="text-end"><strong> <?php echo app('translator')->get('Order Discount'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?></strong></td>
                                <td class="order_discount text-end">
                                    <?php if($sale->order_discount_type == 1): ?>
                                        <?php echo e(App\Utils\Converter::format_in_bdt($sale->order_discount_amount)); ?> (Fixed)
                                    <?php else: ?>
                                        <?php echo e(App\Utils\Converter::format_in_bdt($sale->order_discount_amount)); ?> ( <?php echo e($sale->order_discount); ?>%)
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-end"><strong> <?php echo app('translator')->get('Order Tax'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?></strong></td>
                                <td class="order_tax text-end">
                                    <?php echo e(App\Utils\Converter::format_in_bdt($sale->order_tax_amount)); ?>(<?php echo e($sale->order_tax_percent); ?> %)
                                </td>
                            </tr>

                            <tr>
                                <td class="text-end"><strong> <?php echo app('translator')->get('Shipment charge'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?> </strong></td>
                                <td class="shipment_charge text-end">
                                    <?php echo e(App\Utils\Converter::format_in_bdt($sale->shipment_charge)); ?>

                                </td>
                            </tr>

                            <?php if($previous_due != 0): ?>
                                <tr>
                                    <td class="text-end"><strong> <?php echo app('translator')->get('Previous Due'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?></strong></td>
                                    <td class="total_payable text-end">
                                        <?php echo e(App\Utils\Converter::format_in_bdt($previous_due)); ?>

                                    </td>
                                </tr>
                            <?php endif; ?>

                            <tr>
                                <td class="text-end"><strong> <?php echo app('translator')->get('Total Payable'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?></strong></td>
                                <td class="total_payable text-end">
                                    <?php echo e(App\Utils\Converter::format_in_bdt($total_payable_amount)); ?>

                                </td>
                            </tr>

                            <tr>
                                <td class="text-end"><strong> <?php echo app('translator')->get('Total Paid'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?></strong></td>
                                <td class="total_paid text-end">
                                    <?php echo e(App\Utils\Converter::format_in_bdt($paying_amount)); ?>

                                </td>
                            </tr>

                            <?php if($change_amount > 0): ?>
                                <tr>
                                    <td class="text-end"><strong> <?php echo app('translator')->get('Change Amount'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?></strong></td>
                                    <td class="total_paid text-end">
                                        <?php echo e(App\Utils\Converter::format_in_bdt($change_amount > 0 ? $change_amount : 0)); ?>

                                    </td>
                                </tr>
                            <?php endif; ?>

                            <tr>
                                <td class="text-end"><strong> <?php echo app('translator')->get('Total Due'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?> </strong></td>
                                <td class="total_due text-end">
                                    <?php echo e(App\Utils\Converter::format_in_bdt($total_due > 0 ? $total_due : 0)); ?>

                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div><br><br>

            <div class="row">
                <div class="col-md-3">
                    <div class="details_area text-center">
                        <p class="borderTop"><strong><?php echo app('translator')->get('Customer'); ?>'s signature</strong></p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="details_area text-center">
                        <p class="borderTop"><strong><?php echo app('translator')->get('Checked By'); ?></strong></p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="details_area text-center">
                        <p class="borderTop"><strong><?php echo app('translator')->get('Approved By'); ?></strong></p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="details_area text-center">
                        <p class="borderTop"><strong><?php echo app('translator')->get('Signature Of Authority'); ?></strong></p>
                    </div>
                </div>
            </div><br>

            <div class="row">
                <div class="col-md-12">
                    <div class="invoice_notice">
                        <p><?php echo $defaultLayout->invoice_notice ? '<strong><?php echo app('translator')->get('Attention'); ?> : </strong>' . $defaultLayout->invoice_notice : ''; ?></p>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="footer_text text-center">
                        <p><?php echo e($defaultLayout->footer_text); ?></p>
                    </div>
                </div>
            </div><br>

            <div id="footer">
                <div class="row mt-1">
                    <div class="col-4 text-start">
                        <small><?php echo app('translator')->get('Print Date'); ?> : <?php echo e(date(json_decode($generalSettings->business, true)['date_format'])); ?></small>
                    </div>

                    <div class="col-4 text-center">
                        <?php if(env('PRINT_SD_SALE') == true): ?>
                            <small class="d-block"><?php echo app('translator')->get('Software By'); ?> <strong><?php echo app('translator')->get('SpeedDigit Pvt'); ?>. Ltd.</strong></small>
                        <?php endif; ?>
                    </div>

                    <div class="col-4 text-end">
                        <small><?php echo app('translator')->get('Print Time'); ?> : <?php echo e(date($timeFormat)); ?></small>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <!-- Packing slip print templete-->
    <div class="sale_print_template">
        <style>@page{margin: 8px;}</style>
        <div class="pos_print_template">
            <div class="row">
                <div class="company_info">
                    <table class="w-100">
                        <thead>
                            <tr>
                                <th class="text-center">
                                    <?php if($defaultLayout->show_shop_logo == 1): ?>
                                        <?php if($sale->branch): ?>
                                            <?php if($sale->branch->logo != 'default.png'): ?>
                                                <img style="height: 40px; width:200px;" src="<?php echo e(asset('public/uploads/branch_logo/' . $sale->branch->logo)); ?>">
                                            <?php else: ?>
                                                <span style="font-family: 'Anton', sans-serif; font-size:15px;color:black; font-weight: 500; text-transform: uppercase; letter-spacing: 1px;"><?php echo e($sale->branch->name); ?></span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <?php if(json_decode($generalSettings->business, true)['business_logo'] != null): ?>
                                                <img style="height: 40px; width:200px;" src="<?php echo e(asset('public/uploads/business_logo/' . json_decode($generalSettings->business, true)['business_logo'])); ?>" alt="logo" class="logo__img">
                                            <?php else: ?>
                                                <span style="font-family: 'Anton', sans-serif; font-size:15px;color:black; font-weight: 500; text-transform: uppercase; letter-spacing: 1px;"><?php echo e(json_decode($generalSettings->business, true)['shop_name']); ?></span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </th>
                            </tr>

                            <?php if($sale->branch): ?>
                                <tr>
                                    <th class="text-center">
                                        <h6><?php echo e($sale->branch->name . '/' . $sale->branch->branch_code); ?></h6>
                                    </th>
                                </tr>

                                <tr>
                                    <th class="text-center">
                                        <span><?php echo e($sale->branch->city . ', ' . $sale->branch->state . ', ' . $sale->branch->zip_code . ', ' . $sale->branch->country); ?></span>
                                    </th>
                                </tr>

                                <tr>
                                    <th class="text-center">
                                        <span><b><?php echo app('translator')->get('Phone'); ?> :</b>  <?php echo e($sale->branch->phone); ?></span>
                                    </th>
                                </tr>

                                <tr>
                                    <th class="text-center">
                                        <span><b><?php echo app('translator')->get('Email'); ?> :</b> <?php echo e($sale->branch->email); ?></span>
                                    </th>
                                </tr>
                            <?php else: ?>
                                <tr>
                                    <th class="text-center">
                                        <span><?php echo e(json_decode($generalSettings->business, true)['address']); ?> </span>
                                    </th>
                                </tr>

                                <tr>
                                    <th class="text-center">
                                        <span><b><?php echo app('translator')->get('Phone'); ?> :</b> <?php echo e(json_decode($generalSettings->business, true)['phone']); ?> </span>
                                    </th>
                                </tr>

                                <tr>
                                    <th class="text-center">
                                        <span><b><?php echo app('translator')->get('Email'); ?> :</b> <?php echo e(json_decode($generalSettings->business, true)['email']); ?> </span>
                                    </th>
                                </tr>
                            <?php endif; ?>
                        </thead>
                    </table>
                </div>

                <div class="customer_info mt-2">
                    <table class="w-100">
                        <thead>
                            <tr>
                                <th class="text-center">
                                    <b><?php echo app('translator')->get('Date'); ?>:</b> <span> <?php echo e(date(json_decode($generalSettings->business, true)['date_format'] ,strtotime($sale->date)) . ' ' . date($timeFormat, strtotime($sale->time))); ?></span>
                                </th>
                            </tr>

                            <tr>
                                <th class="text-center">
                                    <b><?php echo app('translator')->get('INV NO'); ?>: </b> <span><?php echo e($sale->invoice_id); ?></span>
                                </th>
                            </tr>

                            <tr>
                                <th class="text-center">
                                    <b><?php echo app('translator')->get('Customer'); ?>:</b> <span><?php echo e($sale->customer ? $sale->customer->name : 'Walk-In-Customer'); ?></span>
                                </th>
                            </tr>

                            <?php if(json_decode($generalSettings->reward_poing_settings, true)['enable_cus_point'] == 1): ?>
                                <tr>
                                    <th class="text-center">
                                        <b><?php echo e(json_decode($generalSettings->reward_poing_settings, true)['point_display_name']); ?> : </b>
                                        <span><?php echo e($sale->customer ? $sale->customer->point : 0); ?></span>
                                    </th>
                                </tr>
                            <?php endif; ?>
                        </thead>
                    </table>
                </div>

                <div class="description_area pt-2 pb-1">
                    <table class="w-100">
                        <thead class="t-head">
                            <tr>
                                <th class="text-start"> <?php echo app('translator')->get('Description'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Qty'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Price'); ?></th>
                                <th class="text-end"><?php echo app('translator')->get('Total'); ?></th>
                            </tr>
                        </thead>
                        <thead class="d-body">
                            <?php $__currentLoopData = $sale->sale_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saleProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php
                                        $variant = $saleProduct->variant ? ' '.$saleProduct->variant->variant_name : '';
                                    ?>
                                    <th class="text-start">
                                        <?php echo e($loop->index + 1); ?>. <?php echo e(Str::limit($saleProduct->product->name, 25, '').$variant); ?><?php echo $saleProduct->ex_quantity != 0 ? '(<strong>EX:</strong>'.$saleProduct->ex_quantity.')' : ''; ?>

                                    </th>

                                    <th class="text-center"><?php echo e((float)$saleProduct->quantity); ?></th>
                                    <th class="text-center"><?php echo e(App\Utils\Converter::format_in_bdt($saleProduct->unit_price_inc_tax)); ?></th>
                                    <th class="text-end"><?php echo e(App\Utils\Converter::format_in_bdt($saleProduct->subtotal)); ?></th>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </thead>
                    </table>
                </div>

                <div class="amount_area">
                    <table class="w-100">
                        <thead>
                            <tr>
                                <th class="text-end"><?php echo app('translator')->get('Net Total'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?> </th>
                                <th class="text-end">
                                    <span>
                                        <?php echo e(App\Utils\Converter::format_in_bdt($sale->net_total_amount)); ?>

                                    </span>
                                </th>
                            </tr>

                            <tr>
                                <th class="text-end"><?php echo app('translator')->get('Discount'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?> </th>
                                <th class="text-end">
                                    <span>
                                        <?php echo e(App\Utils\Converter::format_in_bdt($sale->order_discount_amount)); ?>

                                    </span>
                                </th>
                            </tr>

                            <tr>
                                <th class="text-end"><?php echo app('translator')->get('Order Tax'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?> </th>
                                <th class="text-end">
                                    <span>
                                        (<?php echo e($sale->order_tax_percent); ?> %)
                                    </span>
                                </th>
                            </tr>

                            <?php if($previous_due > 0): ?>
                                <tr>
                                    <th class="text-end"><?php echo app('translator')->get('Previous Due'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?> </th>
                                    <th class="text-end">
                                        <span>
                                            <?php echo e(App\Utils\Converter::format_in_bdt($previous_due)); ?>

                                        </span>
                                    </th>
                                </tr>
                            <?php endif; ?>

                            <tr>
                                <th class="text-end"><?php echo app('translator')->get('Total Payable'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?></th>
                                <th class="text-end">
                                    <span>
                                        <?php echo e(App\Utils\Converter::format_in_bdt($total_payable_amount)); ?>

                                    </span>
                                </th>
                            </tr>

                            <tr>
                                <th class="text-end"> <?php echo app('translator')->get('Paid'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?></th>
                                <th class="text-end">
                                    <span>
                                        <?php echo e(App\Utils\Converter::format_in_bdt($paying_amount)); ?>

                                    </span>
                                </th>
                            </tr>

                            <?php if($sale->ex_status == 0): ?>
                                <?php if($change_amount > 0): ?>
                                    <tr>
                                        <th class="text-end"><strong> <?php echo app('translator')->get('Change Amount'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?></strong></th>
                                        <th class="total_paid text-end">
                                            <span>
                                                <?php echo e(App\Utils\Converter::format_in_bdt($change_amount)); ?>

                                            </span>
                                        </th>
                                    </tr>
                                <?php endif; ?>
                            <?php endif; ?>

                            <tr>
                                <th class="text-end"> <?php echo app('translator')->get('Due'); ?> : <?php echo e(json_decode($generalSettings->business, true)['currency']); ?></th>
                                <th class="text-end">
                                    <span>
                                        <?php echo e(App\Utils\Converter::format_in_bdt($total_due)); ?>

                                    </span>
                                </th>
                            </tr>
                        </thead>
                    </table>
                </div>

                <div class="footer_text_area mt-2">
                    <table class="w-100 ">
                        <thead>
                            <tr>
                                <th class="text-center">
                                    <span><?php echo e($defaultLayout->invoice_notice ?  $defaultLayout->invoice_notice : ''); ?></span>
                                </th>
                            </tr>

                            <tr>
                                <th class="text-center">
                                    <br>
                                    <span><?php echo e($defaultLayout->footer_text ?  $defaultLayout->footer_text : ''); ?></span>
                                </th>
                            </tr>
                        </thead>
                    </table>
                </div>

                <div class="footer_area mt-1">
                    <table class="w-100">
                        <thead>
                            <tr>
                                <th class="text-center">
                                    <img style="width: 170px; height:20px;" src="data:image/png;base64,<?php echo e(base64_encode($generator->getBarcode($sale->invoice_id, $generator::TYPE_CODE_128))); ?>">
                                </th>
                            </tr>

                            <tr>
                                <th class="text-center">
                                    <span><?php echo e($sale->invoice_id); ?></span>
                                </th>
                            </tr>

                            <?php if(env('PRINT_SD_SALE') == true): ?>
                                <tr>
                                    <th class="text-center">
                                        <span><?php echo app('translator')->get('Software By'); ?> <b><?php echo app('translator')->get('SpeedDigit Pvt'); ?>. Ltd.</b> </span>
                                    </th>
                                </tr>
                            <?php endif; ?>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Bileet\Meta\meta-pos\resources\views/sales/save_and_print_template/partials/pos_sale_default_invoice_layout.blade.php ENDPATH**/ ?>