<div class="col-lg-5">
    <div class="row">
        <div class="category-sec col-lg-4 col-4 d-none">
            <div class="left-cat-pos">
                <div class="all-cat">
                    <a href="" data-id="" class="cat-button" tabindex="-1">All</a>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="#" data-id="<?php echo e($cate->id); ?>" class="cat-button" tabindex="-1"><?php echo e($cate->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12 col-12 p-1 pb-0">
            <div class="show-product">
                <div class="product-inner">
                    <div class="category-head">
                        <div class="cat-ban-sec">
                            <div class="row">
                                <div class="col-6">
                                    <select name="category_id" id="category_id" class="form-select form-control cat-bg-1 common_submitable" tabindex="-1">
                                        <option value="">All Categories</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cate->id); ?>"><?php echo e($cate->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-6">
                                    <select id="brand_id" id="brand_id" class="form-select form-control cat-bg-2 bg common_submitable" tabindex="-1">
                                        <option value="">All Brands</option>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="product-area">
                        <div class="data_preloader select_product_preloader">
                            <h6><i class="fas fa-spinner text-primary"></i> Processing...</h6>
                        </div>
                        <div class="product-ctn">
                            <div class="row" id="select_product_list">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function selectProductList() {
        $('.select_product_preloader').show();
        var category_id = $('#category_id').val();
        var brand_id = $('#brand_id').val();
        $.ajax({
            url: "<?php echo e(route('sales.pos.product.list')); ?>",
            type: 'get',
            data: {category_id,brand_id,},
            success: function(data) {
                //console.log(data);
                $('#select_product_list').html(data);
                $('.select_product_preloader').hide();
                activeSelectedItems();
            }
        });
    }
    selectProductList();

    //Submit filter form by select input changing
    $(document).on('change', '.common_submitable', function() {
        selectProductList();
    });

    $(document).on('click', '.cat-button', function(e) {
        e.preventDefault();
        var cate_id = $(this).data('id');
        $('#category_id').val(cate_id);
        selectProductList();
    });
</script>
<?php /**PATH C:\Bileet\Meta\meta-pos\resources\views/sales/pos/partial/select_product_section.blade.php ENDPATH**/ ?>