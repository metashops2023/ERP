<div class="sub_total">
    <div class="row">
        <div class="sub-total-input">
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-6">
                        <div class="row">
                            <label for="inputEmail3" class="col-sm-4 col-form-label text-white">Total Qty:</label>
                            <div class="col-sm-8">
                                <input readonly type="number" step="any" name="total_qty" id="total_qty" value="0.00" class="form-control" tabindex="-1">
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="row">
                            <label for="inputEmail3" class="col-sm-4 col-form-label text-white">Total Item:</label>
                            <div class="col-sm-8 ">
                                <input readonly type="number" step="any" name="total_item" id="total_item" value="0.00" class="form-control" tabindex="-1">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Bileet\Meta\meta-pos\resources\views/sales/pos/partial/total_item_and_qty.blade.php ENDPATH**/ ?>