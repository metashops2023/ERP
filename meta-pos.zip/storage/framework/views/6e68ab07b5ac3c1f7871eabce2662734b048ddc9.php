<?php $__currentLoopData = $posShortMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a href="<?php echo e(route($sm->url)); ?>" title="<?php echo e($sm->name); ?>" class="head-tbl-icon" tabindex="-1"><span class="<?php echo e($sm->icon); ?>" ></span></a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<li>
    <a href="<?php echo e(route('pos.short.menus.modal.form')); ?>" id="addPosShortcutBtn" class="head-tbl-icon border-none" tabindex="-1"><span class="fas fa-plus"></span></a>
</li>


<?php /**PATH C:\Bileet\Meta\meta-pos\resources\views/sales/pos/ajax_view/pos-shortcut-menus.blade.php ENDPATH**/ ?>