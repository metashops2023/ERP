
<?php $__env->startPush('stylesheets'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css"/>
    <link href="<?php echo e(asset('public/backend/asset/css/dashboard.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->permission->dashboard['dash_data'] == '1'): ?>
        <div id="dashboard" class="pb-5">
            <div class="row">
                <div class="main__content">
                    <div class="row mx-3 mt-3 switch_bar_cards">

                        

                        <div class="switch_bar">
                            <a href="<?php echo e(route('short.menus.modal.form')); ?>" class="bar-link" id="addShortcutBtn">
                                <span><i class="fas fa-plus-square text-success"></i></span>
                                <p><?php echo app('translator')->get('Add Shortcut'); ?></p>
                            </a>
                        </div>
                    </div>

                    <div class="">
                        <div class="row mx-2 mt-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <input type="hidden" id="date_range" value="<?php echo e($thisMonth); ?>">
                                <?php if($addons->branches == 1): ?>
                                    <?php if(auth()->user()->role_type == 1 || auth()->user()->role_type == 2): ?>
                                        <div class="select-dropdown">
                                            <select name="branch_id" id="branch_id">
                                                <option value=""><?php echo app('translator')->get('All Business Locations'); ?></option>
                                                <option value="NULL">
                                                    <?php echo e(json_decode($generalSettings->business, true)['shop_name']); ?>

                                                    (Head Office)</option>
                                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $br): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($br->id); ?>">
                                                        <?php echo e($br->name . '/' . $br->branch_code); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    <?php else: ?>
                                        <input type="hidden" id="branch_id" value="<?php echo e(auth()->user()->branch_id); ?>">
                                    <?php endif; ?>
                                <?php endif; ?>
                                <div class="button-group">
                                    <label class="button-group__btn" id="date" data-value="<?php echo e($toDay); ?>">
                                        <input type="radio" name="group" />
                                        <span class="button-group__label"><?php echo app('translator')->get('Current Day'); ?></span>
                                    </label>

                                    <label class="button-group__btn">
                                        <input type="radio" name="group" id="date" data-value="<?php echo e($thisWeek); ?>" />
                                        <span class="button-group__label"><?php echo app('translator')->get('This Week'); ?></span>
                                    </label>

                                    <label class="button-group__btn" id="date" data-value="<?php echo e($thisMonth); ?>">
                                        <input type="radio" checked name="group" />
                                        <span class="button-group__label"><?php echo app('translator')->get('This Month'); ?></span>
                                    </label>

                                    <label class="button-group__btn" id="date" data-value="<?php echo e($thisYear); ?>">
                                        <input type="radio" name="group" />
                                        <span class="button-group__label"><?php echo app('translator')->get('This Year'); ?></span>
                                    </label>

                                    <label class="button-group__btn" id="date" data-value="all_time">
                                        <input type="radio" name="group" />
                                        <span class="button-group__label"><?php echo app('translator')->get('All Time'); ?></span>
                                    </label>
                                </div>
                            </div>
                        </div>

                        
                        <div class="mx-3 mt-2">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="card-counter primary d-flex justify-content-around align-content-center">
                                        <div class="icon">
                                            <i class="fas fa-receipt"></i>
                                        </div>
                                        <div class="numbers px-1">
                                            <h3 class="sub-title"><?php echo app('translator')->get('Total Purchase'); ?></h3>
                                            <h1 class="title">
                                                <i class="fas fa-sync fa-spin card_preloader"></i>
                                                <span class="card_amount" id="total_purchase"></span>
                                            </h1>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="card-counter success d-flex justify-content-around align-content-center">
                                        <div class="icon">
                                            <i class="fas fa-money-check"></i>
                                        </div>
                                        <div class="numbers px-1">
                                            <h3 class="sub-title"><?php echo app('translator')->get('Total Sale'); ?></h3>
                                            <h1 class="title">
                                                <i class="fas fa-sync fa-spin card_preloader"></i>
                                                <span class="card_amount" id="total_sale"></span>
                                            </h1>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="card-counter info d-flex justify-content-around align-content-center">
                                        <div class="icon">
                                            <i class="fas fa-clipboard"></i>
                                        </div>
                                        <div class="numbers px-1">
                                            <h3 class="sub-title"><?php echo app('translator')->get('Purchase Due'); ?></h3>
                                            <h1 class="title">
                                                <i class="fas fa-sync fa-spin card_preloader"></i>
                                                <span class="card_amount" id="total_purchase_due"></span>
                                            </h1>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="card-counter danger d-flex justify-content-around align-content-center">
                                        <div class="icon">
                                            <i class="fas fa-file-invoice"></i>
                                        </div>
                                        <div class="numbers px-1">
                                            <h3 class="sub-title"><?php echo app('translator')->get('Invoice Due'); ?></h3>
                                            <h1 class="title">
                                                <i class="fas fa-sync fa-spin card_preloader"></i>
                                                <span class="card_amount" id="total_sale_due"></span>
                                            </h1>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-3">
                                    <div class="card-counter info d-flex justify-content-around align-content-center">
                                        <div class="icon">
                                            <i class="fas fa-file-invoice-dollar"></i>
                                        </div>
                                        <div class="numbers px-1">
                                            <h3 class="sub-title"><?php echo app('translator')->get('Expense'); ?></h3>
                                            <h1 class="title">
                                                <i class="fas fa-sync fa-spin card_preloader"></i>
                                                <span class="card_amount" id="total_expense"></span>
                                            </h1>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="card-counter danger d-flex justify-content-around align-content-center">
                                        <div class="icon">
                                            <i class="fas fa-user"></i>
                                        </div>
                                        <div class="numbers px-1">
                                            <h3 class="sub-title"><?php echo app('translator')->get('Total User'); ?></h3>
                                            <h1 class="title">
                                                <i class="fas fa-sync fa-spin card_preloader"></i>
                                                <span class="card_amount" id="total_user"></span>
                                            </h1>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="card-counter blue d-flex justify-content-around align-content-center">
                                        <div class="icon">
                                            <i class="fas fa-list"></i>
                                        </div>
                                        <div class="numbers px-1">
                                            <h3 class="sub-title"><?php echo app('translator')->get('Total Products'); ?></h3>
                                            <h1 class="title">
                                                <i class="fas fa-sync fa-spin card_preloader"></i>
                                                <span id="total_product"></span>
                                            </h1>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="card-counter success d-flex justify-content-around align-content-center">
                                        <div class="icon">
                                            <i class="fas fa-balance-scale"></i>
                                        </div>
                                        <div class="numbers px-1">
                                            <h3 class="sub-title"><?php echo app('translator')->get('Total Adjustment'); ?></h3>
                                            <h1 class="title">
                                                <i class="fas fa-sync fa-spin card_preloader"></i>
                                                <span class="card_amount" id="total_adjustment"></span>
                                            </h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row px-3 m-1">
                <section>
                    <div class="row">
                        <div class="form_element">
                            <div class="section-header">
                                <h6>
                                    <span class="fas fa-table"> <?php echo app('translator')->get('Stock Alert Of'); ?> </span>
                                    <b>
                                        <?php if(auth()->user()->branch_id): ?>
                                            <?php echo e(auth()->user()->branch->name.'/'.auth()->user()->branch->branch_code); ?>

                                        <?php else: ?>
                                            <?php echo e(json_decode($generalSettings->business, true)['shop_name']); ?>

                                        <?php endif; ?>
                                    </b>
                                </h6>
                            </div>
                            <div class="widget_content">
                                <div class="mtr-table">
                                    <div class="table-responsive">
                                        <table id="stock_alert_table" class="display data__table data_tble stock_table"
                                            width="100%">
                                            <thead>
                                                <tr>
                                                    <th><?php echo app('translator')->get('S/L'); ?></th>
                                                    <th><?php echo app('translator')->get('Product'); ?></th>
                                                    <th><?php echo app('translator')->get('Product Code (SKU)'); ?></th>
                                                    <th><?php echo app('translator')->get('Current Stock'); ?></th>
                                                </tr>
                                            </thead>
                                            <tbody></tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section>
                    <div class="row">
                        <div class="form_element">
                            <div class="section-header">
                                <span class="fas fa-table"></span>
                                <h6><?php echo app('translator')->get('Sales Order'); ?></h6>
                            </div>
                            <div class="widget_content">
                                <div class="table-responsive">
                                    <table id="sales_order_table" class="display data__table data_tble order_table"
                                        cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th><?php echo app('translator')->get('Date'); ?></th>
                                                <th><?php echo app('translator')->get('Invoice ID'); ?></th>
                                                <th><?php echo app('translator')->get('Branch'); ?></th>
                                                <th><?php echo app('translator')->get('Customer'); ?></th>
                                                <th><?php echo app('translator')->get('Shipment Status'); ?></th>
                                                <th><?php echo app('translator')->get('Created By'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="row px-2">
                <div class="col-md-6">
                    <section>
                        <div class="container">
                            <div class="row">
                                <div class="form_element">
                                    <div class="section-header">
                                        <span class="fas fa-table"></span>
                                        <h6><?php echo app('translator')->get('Sales Payment Due'); ?></h6>
                                    </div>
                                    <div class="widget_content">
                                        <div class="table-responsive">

                                            <table id="sales_payment_due_table"
                                                class="display data__table data_tble due_table" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th><?php echo app('translator')->get('Customer'); ?></th>
                                                        <th><?php echo app('translator')->get('Invoice ID'); ?></th>
                                                        <th><?php echo app('translator')->get('Branch'); ?></th>
                                                        <th><?php echo app('translator')->get('Due Amount'); ?></th>
                                                    </tr>
                                                </thead>
                                                <tbody></tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>

                <div class="col-md-6">
                    <section>
                        <div class="container">
                            <div class="row">
                                <div class="form_element">
                                    <div class="section-header">
                                        <span class="fas fa-table"></span>
                                        <h6><?php echo app('translator')->get('Purchase Payment Due'); ?></h6>
                                    </div>
                                    <div class="widget_content">
                                        <div class="table-responsive">

                                            <table id="purchase_payment_due_table"
                                                class="display data__table data_tble purchase_due_table" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th><?php echo app('translator')->get('Supplier'); ?></th>
                                                        <th><?php echo app('translator')->get('P.Invoice ID'); ?></th>
                                                        <th><?php echo app('translator')->get('Branch'); ?></th>
                                                        <th><?php echo app('translator')->get('Due Amount'); ?></th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>

        <!--Add shortcut menu modal-->
        <div class="modal fade" id="shortcutMenuModal" tabindex="-1" role="dialog" aria-labelledby="staticBackdrop" aria-hidden="true">
            <div class="modal-dialog four-col-modal" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h6 class="modal-title" id="payment_heading"><?php echo app('translator')->get('Add Shortcut Menus'); ?></h6>
                        <a href="" class="close-btn" data-bs-dismiss="modal" aria-label="Close"><span
                            class="fas fa-times"></span></a>
                    </div>
                    <div class="modal-body" id="modal-body_shortcuts">
                        <!--begin::Form-->
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div id="dashboard" class="pb-5">
            <div class="row">
                <div class="main__content">
                </div>
            </div>
            <br><br><br>
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1 class="text-primary display-5">Welcome,
                        <strong><?php echo e(auth()->user()->prefix . ' ' . auth()->user()->name . ' ' . auth()->user()->last_name); ?>!</strong>
                    </h1>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <?php if(auth()->user()->permission->dashboard['dash_data'] == '1'): ?>
        <script>
            $(document).on('click', '#date', function() {
                var date_range = $(this).data('value');
                $('#date_range').val(date_range);
                getCardAmount();
                sale_order_table.ajax.reload();
                sale_due_table.ajax.reload();
                purchase_due_table.ajax.reload();
            });

            $(document).on('change', '#branch_id', function() {
                getCardAmount();
                sale_order_table.ajax.reload();
                sale_due_table.ajax.reload();
                purchase_due_table.ajax.reload();
            });

            var table = $('.stock_table').DataTable({
                dom: "Bfrtip",
                buttons: ["excel", "pdf", "print"],
                processing: true,
                serverSide: true,
                searchable: true,
                "ajax": {
                    "url": "<?php echo e(route('dashboard.stock.alert')); ?>",
                    "data": function(d) {d.branch_id = $('#branch_id').val()}
                },
                // ajax: "<?php echo e(route('dashboard.stock.alert')); ?>",
                columns: [{data: 'DT_RowIndex',name: 'DT_RowIndex'},
                    {data: 'name',name: 'name'},
                    {data: 'product_code',name: 'product_code'},
                    {data: 'stock',name: 'stock'},
                ],
            });

            var sale_order_table = $('.order_table').DataTable({
                dom: "Bfrtip",
                buttons: ["excel", "pdf", "print"],
                "processing": true,
                "serverSide": true,
                aaSorting: [
                    [3, 'asc']
                ],
                "ajax": {
                    "url": "<?php echo e(route('dashboard.sale.order')); ?>",
                    "data": function(d) {d.branch_id = $('#branch_id').val();d.date_range = $('#date_range').val();}
                },
                columns: [{data: 'date',name: 'date'},{data: 'invoice_id',name: 'invoice_id'},{data: 'from',name: 'from'},{data: 'customer',name: 'customer'},{data: 'shipment_status',name: 'shipment_status'},{data: 'created_by',name: 'created_by'},
                ],
            });

            var sale_due_table = $('.due_table').DataTable({
                dom: "Bfrtip",
                buttons: ["excel", "pdf", "print"],
                "processing": true,
                "serverSide": true,
                aaSorting: [
                    [3, 'asc']
                ],
                "ajax": {
                    "url": "<?php echo e(route('dashboard.sale.due')); ?>",
                    "data": function(d) {d.branch_id = $('#branch_id').val();d.date_range = $('#date_range').val();}
                },
                columns: [{data: 'customer',name: 'customer'},{data: 'invoice_id',name: 'invoice_id'},{data: 'from',name: 'from'},{data: 'due',name: 'due'},],
            });

            var purchase_due_table = $('.purchase_due_table').DataTable({
                dom: "Bfrtip",
                buttons: ["excel", "pdf", "print"],
                "processing": true,
                "serverSide": true,
                aaSorting: [
                    [3, 'asc']
                ],
                "ajax": {
                    "url": "<?php echo e(route('dashboard.purchase.due')); ?>",
                    "data": function(d) {d.branch_id = $('#branch_id').val();d.date_range = $('#date_range').val();}
                },
                columns: [{data: 'sup_name',name: 'sup_name'},{data: 'invoice_id',name: 'invoice_id'},{data: 'from',name: 'from'},{data: 'due',name: 'due'},],
            });

            var __currency = "<?php echo e(json_decode($generalSettings->business, true)['currency']); ?>";

            function getCardAmount() {
                var date_range = $('#date_range').val();
                var branch_id = $('#branch_id').val();
                $('.card_preloader').show();
                $('.card_amount').html('');
                $.ajax({
                    url: "<?php echo e(route('dashboard.card.data')); ?>",
                    type: 'get',
                    data: {branch_id,date_range},
                    success: function(data) {
                        $('.card_preloader').hide();
                        $('#total_purchase').html(__currency + ' ' + data.totalPurchase);
                        $('#total_sale').html(__currency + ' ' + data.total_sale);
                        $('#total_purchase_due').html(__currency + ' ' + data.totalPurchaseDue);
                        $('#total_sale_due').html(__currency + ' ' + data.totalSaleDue);
                        $('#total_expense').html(__currency + ' ' + data.totalExpense);
                        $('#total_user').html(data.users);
                        $('#total_product').html(data.products);
                        $('#total_adjustment').html(__currency + ' ' + data.total_adjustment);
                    }
                });
            }
            getCardAmount();

            $(document).on('click', '#addShortcutBtn', function (e) {
               e.preventDefault();
                var url = $(this).attr('href');
                $.get(url, function(data) {
                    $('#modal-body_shortcuts').html(data);
                    $('#shortcutMenuModal').modal('show');
                });
            });

            $(document).on('change', '#check_menu', function () {
                $('#add_shortcut_menu').submit();
            });

            $(document).on('submit', '#add_shortcut_menu', function (e) {
                e.preventDefault();
                var url = $(this).attr('action');
                var request = $(this).serialize();
                $.ajax({
                    url: url,
                    type: 'post',
                    data: request,
                    success: function(data) {
                        allShortcutMenus();
                        //toastr.success(data);
                    }
                });
            });

            // Get all shortcut menus by ajax
            function allShortcutMenus() {
                $.ajax({
                    url: "<?php echo e(route('short.menus.show')); ?>",
                    type: 'get',
                    success: function(data) {
                        $('.switch_bar_cards').html(data);
                    }
                });
            }
            allShortcutMenus();
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bileet\Meta\meta-pos\resources\views/dashboard/dashboard_1.blade.php ENDPATH**/ ?>