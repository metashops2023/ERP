

    <?php $__env->startPush('css'); ?>
        <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
    <?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="form-wraper user_login">
        <div class="container">
            <div class="form-content">
                <div class="inner-div col-lg-7">
                    <div class="border-div">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-12">
                                <div class="form-head">
                                    <div class="head p-1">
                                        <?php if(json_decode($generalSettings->business, true)['business_logo'] != null): ?>

                                            <img src="<?php echo e(asset('public/uploads/business_logo/' . json_decode($generalSettings->business, true)['business_logo'])); ?>" alt="logo" class="logo__img">
                                        <?php else: ?>

                                            <span style="font-family: 'Anton', sans-serif;font-size:15px;color:white;"><?php echo e(json_decode($generalSettings->business, true)['shop_name']); ?></span>
                                        <?php endif; ?>
                                        <span class="head-text">
                                            Meta ERP, Point of Sale software by Meta Shops
                                        </span>
                                    </div>
                                </div>

                                <div class="main-form">
                                   <div class="form_inner">
                                        <div class="form-title">
                                            <p><?php echo app('translator')->get('User Login'); ?></p>
                                        </div>
                                        <form action="<?php echo e(route('login')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="left-inner-addon input-container">
                                                <i class="fa fa-user"></i>
                                                <input type="text" name="username" class="form-control form-st text-center"
                                                    value="<?php echo e(old('username')); ?>" placeholder="<?php echo app('translator')->get('Username'); ?>" required />
                                            </div>
                                            <div class="left-inner-addon input-container">
                                                <i class="fa fa-key"></i>
                                                <input name="password" type="Password"
                                                    class="form-control form-st rounded-bottom text-center" placeholder="<?php echo app('translator')->get('Password'); ?>"
                                                    required />
                                            </div>
                                            <?php if(Session::has('errorMsg')): ?>
                                                <div class="bg-danger p-3 mt-4">
                                                    <p class="text-white">
                                                        <?php echo e(session('errorMsg')); ?>

                                                    </p>
                                                </div>
                                            <?php endif; ?>
                                            <button type="submit" class="submit-button"><?php echo app('translator')->get('Login'); ?></button>
                                            <div class="login_opt_link">
                                                <?php if(Route::has('password.request')): ?>
                                                    <a class="forget-pw" href="<?php echo e(route('password.request')); ?>">
                                                        &nbsp; <?php echo e(__('Forgot Your Password?')); ?>

                                                    </a>
                                                <?php endif; ?>
                                                <div class="form-group cx-box">
                                                    <input type="checkbox" id="remembar" class="form-control">
                                                    <label for="remembar"><?php echo app('translator')->get('Remembar me'); ?></label>
                                                </div>
                                            </div>
                                        </form>
                                   </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6 col-12">
                                <div class="form-head addr">
                                    <div class="head addr-t pt-4">
                                        <div class="px-2">
                                            <p class="logo-main-sec">
                                                <h2>
                                                    Meta ERP
                                                </h2>
                                                
                                            </p>
                                            <p class="version"><?php echo app('translator')->get('Version'); ?>: 1.0</p>
                                            <p class="details"><span><?php echo app('translator')->get('Address'); ?>:</span> Dammam, Saudi Arabia </p>
                                            <p class="details"><span><?php echo app('translator')->get('Support'); ?>:</span> CS@metashops.com.sa <br> 920020347 </p>
                                            <p class="details"><span><?php echo app('translator')->get('Website'); ?>:</span> www.metashops.com.sa </p>

                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="back_btn_wrapper">
        <div class="back_btn">
            <a href="#" class="btn"><?php echo app('translator')->get('menu.back'); ?> </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<style>
    .back_btn_wrapper {
        position: fixed;
        top: 10px;
        right: 10px;
        padding: 6px;
        border-radius: 3px;
        box-shadow: -1px 0px 10px 1px #0a0a0a52;
    }

    .back_btn_wrapper .back_btn {
        border: 1px solid #0f76b673;
        padding: 0px 5px;
        border-radius: 3px;
        -webkit-box-shadow: inset 0 0 5px #666;
        box-shadow: inner 0 0 5px #666;
    }

    .back_btn_wrapper .back_btn a {
        color: white;
        font-size: 13px;
    }

    .back_btn_wrapper .back_btn a:focus {
        outline: unset;
        box-shadow: unset;
    }

    .user_login .form-title {
        background: unset;
        -webkit-box-shadow: unset;
        margin-top: -10px;
    }

    .user_login input.form-control.form-st {
        background: unset;
        border: 1px solid #ffffff69;
        border-radius: 4px;
        color: white;
    }

    .user_login .left-inner-addon.input-container {
        margin-bottom: 3px;
    }

    .main-form {
        margin-top: 11px;
        padding: 6px;
        border-radius: 3px;
        box-shadow: -1px 0px 10px 1px #0a0a0a52;
    }

    .user_login .form_inner {
        border: 1px solid #0f76b673;
        padding: 12px 5px;
        border-radius: 3px;
        -webkit-box-shadow: inset 0 0 5px #666;
        box-shadow: inner 0 0 5px #666;
    }

    .left-inner-addon i {
        color: #f5f5f5!important;
    }

    .btn-fn a {
        color: white;
    }

    .btn-fn a:hover {
        color: white;
    }

    .btn-fn.facebook {
        background: #3A5794;
    }

    .btn-fn.twitter {
        background: #1C9CEA;
    }

    .btn-fn.youtube {
        background: #F70000;
    }

    .version {
        margin-bottom: 40px;
        color: white;
        font-weight: 400;
        font-size: 14px
    }

    .login_opt_link .form-group input {
        display: inline-block;
    }
</style>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bileet\Meta\meta-pos\resources\views/auth/login.blade.php ENDPATH**/ ?>