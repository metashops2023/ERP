<header>
    <div class="navigation red_linear_bg">
        <div class="panel__nav">
            <div class="top-menu">
                <div class="logo__sec">
                    <a href="<?php echo e(route('dashboard.dashboard')); ?>" class="logo">
                        <?php if(auth()->user()->branch): ?>
                            <?php if(auth()->user()->branch->logo != 'default.png'): ?>
                                <img style="height: 40px; width:110px;"
                                src="<?php echo e(asset('public/uploads/branch_logo/' . auth()->user()->branch->logo)); ?>">
                            <?php else: ?>
                                <span style="font-family: 'Anton', sans-serif;font-size:15px;color:white;letter-spacing:1px;padding-top:15px;display:inline-block;"><?php echo e(auth()->user()->branch->name); ?></span>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if(json_decode($generalSettings->business, true)['business_logo'] != null): ?>
                                <img style="height: 40px; width:110px;"
                                src="<?php echo e(asset('public/uploads/business_logo/' . json_decode($generalSettings->business, true)['business_logo'])); ?>"
                                alt="logo" class="logo__img">
                            <?php else: ?>
                                <span style="font-family: 'Anton', sans-serif;font-size:15px;color:white;letter-spacing:1px;padding-top:15px;display:inline-block;"><?php echo e(json_decode($generalSettings->business, true)['shop_name']); ?></span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </a>
                </div>
                <div class="notify-menu">
                    <div class="head__content__sec">
                        <ul class="head__cn">
                            <li class="top-icon d-none d-md-block" id="hard_reload"><a href="#" title="Reload"><b><span class="fas fa-redo-alt"></span></b></a></li>
                            <?php if($addons->e_commerce == 1): ?>
                                <li class="top-icon d-none d-md-block"><a href="#" target="_blank"><b><span class="fas fa-globe"></span></b></a></li>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->others['communication'] == '1'): ?>
                                <li class="top-icon d-none d-md-block" id="get_mail" title="Communicate"><a href="#"><b><i
                                                class="fas fa-th-large"></i></b></a>
                                    <ul class="lists">
                                        <li><a href="#"><i class="fas fa-bell"></i>
                                            <span class="title"><?php echo app('translator')->get('Notice Board'); ?></span></a> </li>
                                        <li><a href="#"><i class="fas fa-envelope-open"></i><span class="title">Send
                                                    Email</span></a></li>
                                        <li><a href="#"><i class="fas fa-comment-alt"></i><span class="title">Send
                                                    SMS</span></a></li>
                                        <li><a href="#"><i class="fas fa-download"></i><span class="title">Download
                                                    Center</span></a></li>
                                    </ul>
                                </li>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->others['today_summery'] == '1'): ?>
                                <li class="top-icon"><a href="#" id="today_summery"><b><?php echo app('translator')->get('Today'); ?></b></a></li>
                            <?php endif; ?>

                            <li class="top-icon"><a href=""><i class="far fa-bell"></i></a></li>
                            <?php if(json_decode($generalSettings->modules, true)['pos'] == '1'): ?>
                                <?php if(auth()->user()->permission->sale['pos_add'] == '1'): ?>
                                    <li class="top-icon"><a href="<?php echo e(route('sales.pos.create')); ?>"><b><?php echo app('translator')->get('POS'); ?></b></a></li>
                                <?php endif; ?>
                            <?php endif; ?>

                            <li class="top-icon">
                                <a href="" class="pos-btn" data-bs-toggle="modal" data-bs-target="#calculatorModal">
                                    <span class="fas fa-calculator"></span>
                                </a>
                                <div class="modal" id="calculatorModal" tabindex="-1"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modail-body" id="calculator">
                                                <div class="calculator-bg" dir="ltr">
                                                    <div class="calculator-bg__main">
                                                        <div class="calculator-bg__main__screen">
                                                            <div class="calculator-bg__main__screen__first"></div>
                                                            <div class="calculator-bg__main__screen__second">0</div>
                                                        </div>
                                                        <button class="calculator-bg__main__ac">AC</button>
                                                        <button class="calculator-bg__main__del"><?php echo app('translator')->get('DEL'); ?></button>
                                                        <button class="calculator-bg__main__operator">/</button>
                                                        <button class="calculator-bg__main__num">7</button>
                                                        <button class="calculator-bg__main__num">8</button>
                                                        <button class="calculator-bg__main__num">9</button>
                                                        <button class="calculator-bg__main__operator">x</button>
                                                        <button class="calculator-bg__main__num">4</button>
                                                        <button class="calculator-bg__main__num">5</button>
                                                        <button class="calculator-bg__main__num">6</button>
                                                        <button class="calculator-bg__main__operator">+</button>
                                                        <button class="calculator-bg__main__num">1</button>
                                                        <button class="calculator-bg__main__num">2</button>
                                                        <button class="calculator-bg__main__num">3</button>
                                                        <button class="calculator-bg__main__operator">-</button>
                                                        <button class="calculator-bg__main__num decimal">.</button>
                                                        <button class="calculator-bg__main__num">0</button>
                                                        <button class="calculator-bg__main__result">=</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="dropdown dp__top">
                                <a href="" class="top-icon" id="dropdownMenuButton1" data-bs-toggle="dropdown">
                                    <i class="fas fa-language"></i>
                                </a>

                                <ul class="dropdown-menu dropdown__main__menu " aria-labelledby="dropdownMenuButton1">
                                    <li>
                                        <a style="display:inline;" class="dropdown-item <?php if(app()->isLocale('en')): ?> text-primary <?php endif; ?>" href="<?php echo e(route('change.lang', 'en')); ?>">
                                            English
                                        </a>
                                    </li>
                                    <li>
                                        <a style="display:inline;" class="dropdown-item <?php if(app()->isLocale('ar')): ?> text-primary <?php endif; ?>" href="<?php echo e(route('change.lang', 'ar')); ?>">
                                            Arabic
                                        </a>
                                    </li>
                                    <li>
                                        <a style="display:inline;" class="dropdown-item <?php if(app()->isLocale('bn')): ?> text-primary <?php endif; ?>" href="<?php echo e(route('change.lang', 'bn')); ?>">
                                            Bangla
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="top-icon d-none d-md-block"><a href="https://help.genuinepos.com/"
                                    target="_blank"><b><span class="far fa-question-circle"></span></b></a></li>
                            <li class="dropdown dp__top top-icon">
                                <a href="" class="" id="dropdownMenuButton1" data-bs-toggle="dropdown" title="User">
                                    <span class="fas fa-user"></span>
                                </a>

                                <ul class="dropdown-menu dropdown__main__menu" aria-labelledby="dropdownMenuButton1">
                                    <li>
                                        <span class="user_name text-primary">
                                            <?php echo e(auth()->user()->prefix . ' ' . auth()->user()->name . ' ' .
                                            auth()->user()->last_name); ?>

                                            <?php if(auth()->user()->role_type == 1): ?>
                                                (Super Admin)
                                            <?php elseif(auth()->user()->role_type == 2): ?>
                                                (Admin)
                                            <?php else: ?>
                                                <?php echo e(auth()->user()->role->name); ?>

                                            <?php endif; ?>
                                        </span>
                                    </li>

                                    <li>
                                        <i class="fas fa-eye text-primary"></i><a class="dropdown-item d-block"
                                            href="<?php echo e(route('users.profile.view', auth()->user()->id)); ?>">
                                        <?php echo app('translator')->get('View Profile'); ?></a>
                                    </li>

                                    <li>
                                        <i class="fas fa-edit text-primary"></i></span><a class="dropdown-item d-block"
                                            href="<?php echo e(route('users.profile.index')); ?>"><?php echo app('translator')->get('Edit Profile'); ?></a>
                                    </li>
                                </ul>
                            </li>
                            </li>
                            <li class="top-icon">
                                <a href="" id="logout_option"><span class="fas fa-power-off" title="Logout"></span></a>
                            </li>
                        </ul>
                    </div>

                </div>
                <div id="left_bar_toggle"><span class="fas fa-bars"></span></div>
            </div>
        </div>
    </div>
</header>

<?php /**PATH C:\Bileet\Meta\meta-pos\resources\views/partials/header.blade.php ENDPATH**/ ?>