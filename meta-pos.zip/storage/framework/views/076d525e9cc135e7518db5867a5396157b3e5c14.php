<style>
    .cash_receive_input{
      background-color: white;
      border: 1px solid #ced4da;
      letter-spacing: -3px!important;
      padding: 0px 3px 0px 0px!important;
      font-weight: 700!important;
    }

    .check-out-woaper{
        background:white !important;
    }
    .btn-bg{
       background: white !important;
       border: none !important;
    }
    .function-cards{
        padding-top: 5px !important;
    }
    .function-cards,
    .function-cards2,
    .function-cards3{
        font-size: 11px !important;
        margin-left:10px !important;
        color:white !important;
        height :40px !important ;
        display: inline-block !important;
        border-radius:9px !important;
        text-align:center !important;
        max-width:100px !important;
        background:rgb(2, 113, 240) !important;
        border: none !important;
        padding-bottom:0px !important;
        /* box-shadow:0px 0px 7px 0.3px gray ; */
    }
    .function-cards2{
        background:#004e92 !important;
        border: none !important;
        max-width:100px !important;
        line-height: 20px !important;
    }
    .function-cards3{
        background:#3c1053 !important;
        border: none !important;
        max-width:100px !important;
        line-height: 20px !important;
        }
    .wrapper_input_btn label{
        color:black !important;
    }
    .wrapper_input_btn input,
    .wrapper_input_btn select{
        border-radius:5px !important;
    }
    .wrapper_input_btn .cash_receive_input{
        border-top-left-radius:5px !important;
        border-bottom-left-radius:5px !important;
    }
    .wrapper_input_btn .aaa{
        border-top-left-radius:0px !important;
        border-bottom-left-radius:0px !important;
    }
    .function-sec{
     width:100% !important;
    }
    .wrapper_input_btn{
        position:static !important;
        padding-left:15px !important;
        padding-top: 25px !important;
    }
    .check-out-woaper{
        gap:0px !important;
    }
    .function-cards4{
        font-size: 13px !important;
        margin-left:10px !important;
        color:white !important;
        height :49px !important ;
        display: inline-block !important;
        border-radius:9px !important;
        text-align:center !important;
        background:rgb(2, 113, 240) !important;
        border: none !important;
        padding-bottom:0px !important;
        /* box-shadow:0px 0px 7px 0.3px gray ; */
    }
   
</style>

<div class="col-lg-3 p-1 px-0">
    <div class="pos-right-inner ps-0">
        <div class="check-out-woaper pt-4 ps-0">
            <div class="function-sec px-0">
                <div class="row px-0">
                    <div class="col-4 px-2 py-1">
                        <div class="btn-bg1">
                            <a href="#"
                                <?php if(json_decode($generalSettings->pos, true)['is_enabled_draft'] == '1'): ?>
                                    data-button_type="0"
                                    data-action_id="2"
                                    id="submit_btn"
                                <?php else: ?>
                                    onclick="
                                        event.preventDefault();
                                        toastr.error('Creating draft is disabled in POS.');
                                    "
                                <?php endif; ?>
                                class="bg-orange function-cards" tabindex="-1">Draft F2
                            </a>
                        </div>
                    </div>

                    <div class="col-4 px-2 py-1">
                        <div class="btn-bg1">
                            <a href="#"
                                <?php if(json_decode($generalSettings->pos, true)['is_enabled_quotation'] == '1'): ?>
                                    data-action_id="4"
                                    data-button_type="0"
                                    id="submit_btn"
                                <?php else: ?>
                                    onclick="
                                        event.preventDefault();
                                        toastr.error('Creating quotaion is disabled in POS.');
                                    "
                                <?php endif; ?>
                                class="bg-orange function-cards" tabindex="-1">Quotation F4
                            </a>
                        </div>
                    </div>

                    <div class="col-4 px-2 py-1">
                        <div class="btn-bg1">
                            <a href="#" class="bg-orange function-cards" id="exchange_btn" data-bs-toggle="modal" data-bs-target="#exchangeModal" tabindex="-1">
                                Exchange F6
                            </a>
                        </div>
                    </div>

                    <div class="col-4 px-2 mt-2 py-1">
                        <div class="btn-bg1">
                            <a href="#" class="bg-gren function-cards2" id="show_stock" tabindex="-1">Stock<p>Alt+C</p>
                            </a>
                        </div>
                    </div>

                    <div class="col-4 px-2 mt-2 py-1">
                        <div class="btn-bg1">
                            <a href="#"
                                <?php if(json_decode($generalSettings->pos, true)['is_enabled_hold_invoice'] == '1'): ?>
                                    data-button_type="0"
                                    data-action_id="5"
                                    id="submit_btn"
                                <?php else: ?>
                                    onclick="
                                        event.preventDefault();
                                        toastr.error('Hold invoice is disabled in POS.');
                                    "
                                <?php endif; ?>
                                class="bg-gren function-cards2" tabindex="-1">Hold Invoice<p>F8</p>
                            </a>
                        </div>
                    </div>

                    <div class="col-4 px-2 mt-2 py-1">
                        <div class="btn-bg1">
                            <a href="#"
                                <?php if(json_decode($generalSettings->pos, true)['is_enabled_hold_invoice'] == '1'): ?>
                                    id="pick_hold_btn"
                                <?php else: ?>
                                    onclick="
                                        event.preventDefault();
                                        toastr.error('Hold invoice is disabled in POS.');
                                    "
                                <?php endif; ?>
                                class="bg-gren function-cards2" tabindex="-1">Pick Hold <p>F9</p>
                            </a>
                        </div>
                    </div>

                    <div class="col-4 px-2 py-1">
                        <div class="btn-bg1">
                            <a href="<?php echo e(route('settings.general.index')); ?>" class="mt-2 bg-swit function-cards3" tabindex="-1">
                                Setup <p>Ctrl+Q</p>
                            </a>
                        </div>
                    </div>

                    <div class="col-4 px-2 py-1">
                        <div class="btn-bg1">
                            <a href="#"
                                <?php if(json_decode($generalSettings->pos, true)['is_enabled_suspend'] == '1'): ?>
                                    data-button_type="0"
                                    data-action_id="6"
                                    id="submit_btn"
                                <?php else: ?>
                                    onclick="
                                        event.preventDefault();
                                        toastr.error('Suspend is disabled in POS.');
                                    "
                                <?php endif; ?>
                                class="bg-swit mt-2 function-cards3" tabindex="-1">Suspend<p>Alt+A</p>
                            </a>
                        </div>
                    </div>

                    <div class="col-4 px-2 py-1">
                        <div class="btn-bg1">
                            <a href="#" class="bg-swit mt-2 function-cards3" onclick="cancel(); return false;" tabindex="-1">
                                Cancel <p>Ctrl+M</p>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="wrapper_input_btn pe-0">
                <div class="checkout-input-sec">
                    <div class="row">
                        <label for="inputEmail3" class="col-sm-3 col-form-label text-white"><b>Total:</b></label>
                        <div class="col-sm-9">
                            <input readonly type="number" class="form-control pos-amounts" name="net_total_amount" id="net_total_amount" value="0.00" tabindex="-1">
                        </div>
                    </div>

                    <?php if(json_decode($generalSettings->pos, true)['is_enabled_discount'] == '1'): ?>
                        <div class="row">
                            <label class="col-sm-3 col-form-label text-white">Discount:</label>
                            <div class="col-sm-9">

                                <div class="row">
                                    <div class="col-md-6">
                                        <select name="order_discount_type" id="order_discount_type" class="form-control pos-amounts">
                                            <option value="1">Fixed(0.00)</option>
                                            <option value="2">Percent(%)</option>
                                        </select>
                                        
                                    </div>

                                    <div class="col-md-6">
                                        <input name="order_discount" type="number" step="any" class="form-control pos-amounts" id="order_discount" value="0.00">
                                    </div>
                                </div>

                                <input name="order_discount_amount" type="number" class="d-none" id="order_discount_amount"
                                    value="0.00" tabindex="-1">
                            </div>
                        </div>
                    <?php else: ?>
                        <input name="order_discount" type="hidden" id="order_discount" value="0.00" tabindex="-1">
                        <input name="order_discount_amount" type="number" class="d-none" id="order_discount_amount"
                            value="0.00" tabindex="-1">
                        <input name="order_discount_type" class="d-none" id="order_discount_type" value="1">
                    <?php endif; ?>

                    <?php if(json_decode($generalSettings->pos, true)['is_enabled_order_tax'] == '1'): ?>
                        <div class="row">
                            <label class="col-sm-3 col-form-label text-white">Vat/Tax:</label>
                            <div class="col-sm-9">
                                <div class="row">
                                    <div class="col-md-6">
                                        <select name="order_tax" class="form-control pos-amounts" id="order_tax"></select>
                                    </div>

                                    <div class="col-md-6">
                                        <input type="number" class="form-control pos-amounts" name="order_tax_amount" id="order_tax_amount"
                                        value="0.00">
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <input name="order_tax" type="hidden" id="order_tax" value="0.00" tabindex="-1">
                        <input type="hidden" name="order_tax_amount" id="order_tax_amount" value="0.00" tabindex="-1">
                    <?php endif; ?>

                    <div class="row">
                        <label class="col-sm-3 col-form-label text-white">Pre. Due:</label>

                        <div class="col-sm-9">
                            <input readonly class="form-control pos-amounts" type="number" step="any" name="previous_due"
                                id="previous_due" value="0.00" tabindex="-1">
                        </div>

                        <label class="col-sm-3 col-form-label text-white">Payable:</label>
                        <div class="col-sm-9 ">
                            <input readonly class="form-control pos-amounts" type="number" step="any"
                                name="total_payable_amount" id="total_payable_amount" value="0.00" tabindex="-1">

                            <input class="d-none" type="number" step="any" name="total_invoice_payable"
                                id="total_invoice_payable" value="0.00" tabindex="-1">
                        </div>
                    </div>

                    <div class="row">
                        <label class="col-sm-6 col-form-label text-white">Cash Receive:</label>
                        <div class="col-sm-6">
                            

                            <div class="input-group">
                                <span class="input-group-text cash_receive_input">>></span>
                                <input type="number" step="any" name="paying_amount" id="paying_amount" value="0"
                                class="form-control aaa pos-amounts input_i" autocomplete="off">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <label class="col-sm-6 col-form-label text-white">Change Amount:</label>
                        <div class="col-sm-6 ">
                            <input readonly type="text" name="change_amount" id="change_amount" value="0.00"
                                class="form-control pos-amounts" tabindex="-1">
                        </div>
                    </div>

                    <div class="row">
                        <label class="col-sm-6 col-form-label text-danger"><b>Due :</b></label>
                        <div class="col-sm-6 ">
                            <input type="text" readonly name="total_due" id="total_due" value="0.00"
                                class="form-control pos-amounts text-danger" tabindex="-1">
                        </div>
                    </div>
                </div>

                <div class="sub-btn-sec pt-1">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-12 p-1 pb-1">
                            <div class="btn-bg1 mb-1">
                                <a href="#" class="bg-orange pt-2 btn-pos text-center function-cards4"
                                    <?php if(json_decode($generalSettings->pos, true)['is_enabled_credit_full_sale'] == '1'): ?>
                                        data-button_type="0"
                                        id="full_due_button"
                                    <?php else: ?>
                                        onclick="
                                            event.preventDefault();
                                            toastr.error('Full credit sale is disabled.');
                                        "
                                    <?php endif; ?>
                                    tabindex="-1"><i class="fas fa-check"></i> Credit Sale</a>
                            </div>

                          
                        </div>
                        <div class="col-lg-6 col-md-6 col-12 p-1 pb-1">
                        <div class="btn-bg1">
                                <a href="#" class="function-cards4 pt-2 text-center bg-parpal btn-pos" id="reedem_point_button" tabindex="-1">Reedem Point</a>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6 col-12 p-1 pb-0 btn-bottom">
                            <div class="btn-bg1">
                                <a href="#" class="bg-parpal function-cards4 other_payment_method" tabindex="-1">
                                    <i class="fas fa-credit-card"></i> Other Method
                                    <p>Ctrl+B</p>
                                </a>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6 col-12 p-1 text-center btn-bottom">
                            <div class="btn-bg1">
                                <a href="#" class="bg-parpal function-cards4 cash-btn text-center pt-0" id="submit_btn" data-button_type="1"
                                    data-action_id="1" tabindex="-1">
                                    <i class="far fa-money-bill-alt"></i>Cash <p>F10</p> 
                                    
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    var actionMessage = 'Data inserted Successfull.';

    $('#pos_submit_form').on('submit', function(e) {
        e.preventDefault();
        $('.loading_button').show();
        var request = $(this).serialize();
        var url = $(this).attr('action');
        $('.submit_preloader').show();
        $.ajax({
            url:url,
            type:'post',
            data: request,
            success:function(data){
                $('.loading_button').hide();
                $('.submit_preloader').hide();

                if(!$.isEmptyObject(data.errorMsg)){

                    toastr.error(data.errorMsg,'Attention');
                    return;
                }else if(data.suspendMsg){

                    toastr.success(data.suspendMsg);
                    afterSubmitForm();
                    document.getElementById('search_product').focus();
                }else if(data.holdInvoiceMsg){

                    toastr.success(data.holdInvoiceMsg);
                    afterSubmitForm();
                    document.getElementById('search_product').focus();
                }else {

                    toastr.success(actionMessage);
                    afterSubmitForm();
                    $(data).printThis({
                        debug: false,
                        importCSS: true,
                        importStyle: true,
                        loadCSS: "<?php echo e(asset('assets/css/print/sale.print.css')); ?>",
                        removeInline: false,
                        printDelay: 1000,
                        header: null,
                    });
                    document.getElementById('search_product').focus();
                }
            },error: function(err) {

                $('.loading_button').hide();
                $('.submit_preloader').hide();
                if (err.status == 0) {

                    toastr.error('Net Connetion Error. Reload This Page.');
                    return;
                }else if (err.status == 500) {

                    toastr.error('Server error. Please contact the support team.');
                    return;
                }

                $.each(err.responseJSON.errors, function(key, error) {
                    toastr.error(error[0]);
                });
            }
        });
    });

    <?php if(json_decode($generalSettings->pos, true)['is_enabled_hold_invoice'] == '1'): ?>
        //Key shorcut for pic hold invoice
        shortcuts.add('f9',function() {
            $('#hold_invoice_preloader').show();
            pickHoldInvoice();
        });

        // Pick hold invoice
        $(document).on('click', '#pick_hold_btn',function (e) {
            e.preventDefault();
            $('#hold_invoice_preloader').show();
            pickHoldInvoice();
        });

        function pickHoldInvoice() {
            $('#holdInvoiceModal').modal('show');
            $.ajax({
                url:"<?php echo e(url('sales/pos/pick/hold/invoice/')); ?>",
                type:'get',
                success:function(data){
                    $('#hold_invoices').html(data);
                    $('#hold_invoice_preloader').hide();
                }
            });
        }
    <?php endif; ?>

    function showStock() {
        $('#stock_preloader').show();
        $('#showStockModal').modal('show');
        $.ajax({
            url:"<?php echo e(route('sales.pos.branch.stock')); ?>",
            type:'get',
            success:function(data){
                $('#stock_modal_body').html(data);
                $('#stock_preloader').hide();
            }
        });
    }
</script>
<?php /**PATH C:\Bileet\Meta\meta-pos\resources\views/sales/pos/partial/total_sum_and_butten.blade.php ENDPATH**/ ?>