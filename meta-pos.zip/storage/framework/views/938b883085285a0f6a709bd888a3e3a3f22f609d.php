<!DOCTYPE html>
<?php
    $rtl = app()->isLocale('ar');
?>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Fab-Icon -->
    <link rel="shortcut icon" href="<?php echo e(asset('public/favicon.png')); ?>">

    <!-- Title -->
    <title><?php echo $__env->yieldContent('title'); ?> <?php echo e(json_decode($generalSettings->business, true)['shop_name'] ?? config('app.name')); ?></title>

    <!-- Stylesheets -->

    <?php echo $__env->make('layout._stylesheet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('stylesheets'); ?>

</head>
<body id="dashboard-8" class="<?php echo e(json_decode($generalSettings->system, true)['theme_color'] ?? 'dark-theme'); ?> <?php if($rtl): ?> rtl <?php endif; ?>" <?php if($rtl): ?> dir="rtl" <?php endif; ?>>
    <div class="all__content">
        <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="main-woaper">
            <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="bg-color-body">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        
    </div>

    <div class="modal fade" id="todaySummeryModal" tabindex="-1" role="dialog" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="staticBackdrop" aria-hidden="true">
        <div class="modal-dialog four-col-modal" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title" id="exampleModalLabel"><?php echo app('translator')->get('Today Summery'); ?></h6>
                    <a href="" class="close-btn" data-bs-dismiss="modal" aria-label="Close"><span
                            class="fas fa-times"></span></a>
                </div>
                <div class="modal-body" id="today_summery_modal_body">
                    <div class="today_summery_modal_contant">

                    </div>
                    <div class="print-button-area">
                        <a href="#" class="btn btn-sm btn-primary float-end" id="today_summery_print_btn"><?php echo app('translator')->get('Print'); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layout._script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script>
        $(document).on('click', '#today_summery',function (e) {
            e.preventDefault();
            todaySummery();
        });

        function todaySummery() {
            var branch_id = $('#today_branch_id').val();
            $('.loader').show();
            $.ajax({
                url: "<?php echo e(route('dashboard.today.summery')); ?>",
                type: 'get',
                data: {branch_id},
                success: function(data) {
                    $('.today_summery_modal_contant').html(data);
                    $('#todaySummeryModal').modal('show');
                    $('.loader').hide();
                }
            });
        }

        $(document).on('change', '#today_branch_id',function () {
            todaySummery();
        });

        $(document).on('click', '#today_summery_print_btn', function (e) {
            e.preventDefault();
            var body = $('.print_body').html();
            var header = $('.print_today_summery_header').html();
            var footer = $('.print_today_summery_footer').html();
            $(body).printThis({
                debug: false,
                importCSS: true,
                importStyle: true,
                loadCSS: "<?php echo e(asset('public/assets/css/print/purchase.print.css')); ?>",
                removeInline: true,
                printDelay: 500,
                header: header,
                footer: footer
            });
        });
    </script>
    <!-- Logout form for global -->
    <form id="logout_form" class="d-none" action="<?php echo e(route('logout')); ?>" method="POST"><?php echo csrf_field(); ?></form>
    <!-- Logout form for global end -->
</body>

</html>
<?php /**PATH C:\Bileet\Meta\meta-pos\resources\views/layout/master.blade.php ENDPATH**/ ?>