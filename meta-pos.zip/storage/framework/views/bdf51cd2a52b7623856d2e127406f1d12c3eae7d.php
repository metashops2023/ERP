<div id="primary_nav" class="g_blue toggle-leftbar">
    <div class="first__left">
        <div class="main__nav">
            <ul id="" class="float-right">
                <li data-menu="dashboardmenu" class="">
                    <a href="<?php echo e(route('dashboard.dashboard')); ?>" class="">
                        <img src="<?php echo e(asset('public/backend/asset/img/icon/pie-chart.svg')); ?>" alt="">
                        <p class="title"><?php echo app('translator')->get('Dashboard'); ?></p>
                    </a>
                </li>

                <?php if($addons->branches == 1): ?>
                    <li data-menu="superadmin" class="">
                        <a href="#" class=""><img src="<?php echo e(asset('public/backend/asset/img/icon/superadmin.svg')); ?>">
                            <p class="title"><?php echo app('translator')->get('menu.superadmin'); ?></p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(json_decode($generalSettings->modules, true)['contacts'] == '1'): ?>
                    <?php if(
                        auth()->user()->permission->contact['supplier_all'] == '1' ||
                        auth()->user()->permission->contact['supplier_add'] == '1' ||
                        auth()->user()->permission->contact['supplier_import'] == '1' ||
                        auth()->user()->permission->contact['customer_all'] == '1' ||
                        auth()->user()->permission->contact['customer_add'] == '1' ||
                        auth()->user()->permission->contact['customer_import'] == '1' ||
                        auth()->user()->permission->contact['customer_group'] == '1' ||
                        (
                            isset(auth()->user()->permission->contact['supplier_report']) &&
                            auth()->user()->permission->contact['supplier_report'] == '1'
                        ) ||
                        (
                            isset(auth()->user()->permission->contact['customer_report']) &&
                            auth()->user()->permission->contact['customer_report'] == '1'
                        )

                    ): ?>
                        <li data-menu="contact" class="<?php echo e(request()->is('contacts*') ? 'menu_active' : ''); ?>">
                            <a href="#" class=""><img src="<?php echo e(asset('public/backend/asset/img/icon/agenda.svg')); ?>">
                                <p class="title"><?php echo app('translator')->get('menu.contacts'); ?></p>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if(
                    auth()->user()->permission->product['product_all'] == '1' ||
                    auth()->user()->permission->product['product_add'] == '1' ||
                    auth()->user()->permission->product['categories'] == '1' ||
                    auth()->user()->permission->product['brand'] == '1' ||
                    auth()->user()->permission->product['units'] == '1' ||
                    auth()->user()->permission->product['variant'] == '1' ||
                    auth()->user()->permission->product['warranties'] == '1' ||
                    auth()->user()->permission->product['selling_price_group'] == '1' ||
                    auth()->user()->permission->product['generate_barcode'] == '1' ||
                    (
                        isset(auth()->user()->permission->product['product_settings']) &&
                        auth()->user()->permission->product['product_settings'] == '1'
                    ) ||
                    (
                        isset(auth()->user()->permission->product['stock_report']) &&
                        auth()->user()->permission->product['stock_report'] == '1'
                    ) ||
                    (
                        isset(auth()->user()->permission->product['stock_in_out_report']) &&
                        auth()->user()->permission->product['stock_in_out_report'] == '1'
                    )
                ): ?>
                    <li data-menu="product" class="<?php echo e(request()->is('product*') ? 'menu_active' : ''); ?>">
                        <a href="#">
                            <img src="<?php echo e(asset('public/backend/asset/img/icon/package.svg')); ?>" alt="">
                            <p class="title"><?php echo app('translator')->get('menu.product'); ?></p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(json_decode($generalSettings->modules, true)['purchases'] == '1'): ?>

                    <?php if(auth()->user()->role_type == 1 || auth()->user()->role_type == 2): ?>
                        <li data-menu="purchases" class="<?php echo e(request()->is('purchases*') ? 'menu_active' : ''); ?>">
                            <a href="#" class="">
                                <img src="<?php echo e(asset('public/backend/asset/img/icon/bill.svg')); ?>">
                                <p class="title"><?php echo app('translator')->get('menu.purchases'); ?></p>
                            </a>
                        </li>
                    <?php else: ?>
                        <?php if(auth()->user()->branch_id && auth()->user()->branch->purchase_permission == 1): ?>

                            <?php if(auth()->user()->permission->purchase['purchase_all'] == '1'): ?>

                                <li data-menu="purchases" class="<?php echo e(request()->is('purchases*') ? 'menu_active' : ''); ?>">
                                    <a href="#" class="">
                                        <img src="<?php echo e(asset('public/backend/asset/img/icon/bill.svg')); ?>">
                                        <p class="title"><?php echo app('translator')->get('menu.purchases'); ?></p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if(
                    auth()->user()->permission->sale['pos_all'] == '1' ||
                    auth()->user()->permission->sale['pos_add'] == '1' ||
                    auth()->user()->permission->sale['create_add_sale'] == '1' ||
                    auth()->user()->permission->sale['view_add_sale'] == '1' ||
                    auth()->user()->permission->sale['sale_draft'] == '1' ||
                    auth()->user()->permission->sale['sale_quotation'] == '1' ||
                    auth()->user()->permission->sale['shipment_access'] == '1' ||
                    auth()->user()->permission->sale['return_access'] == '1' ||
                    (
                        isset(auth()->user()->permission->sale['pos_sale_settings']) &&
                        auth()->user()->permission->sale['pos_sale_settings'] == '1'
                    ) ||
                    (
                        isset(auth()->user()->permission->sale['add_sale_settings']) &&
                        auth()->user()->permission->sale['add_sale_settings'] == '1'
                    ) ||
                    (
                        isset(auth()->user()->permission->sale['discounts']) &&
                        auth()->user()->permission->sale['discounts'] == '1'
                    ) ||
                    (
                        isset(auth()->user()->permission->sale['sale_statements']) &&
                        auth()->user()->permission->sale['sale_statements'] == '1'
                    ) ||
                    (
                        isset(auth()->user()->permission->sale['sale_return_statements']) &&
                        auth()->user()->permission->sale['sale_return_statements'] == '1'
                    ) ||
                    (
                        isset(auth()->user()->permission->sale['pro_sale_report']) &&
                        auth()->user()->permission->sale['pro_sale_report'] == '1'
                    ) ||
                    (
                        isset(auth()->user()->permission->sale['sale_payment_report']) &&
                        auth()->user()->permission->sale['sale_payment_report'] == '1'
                    ) ||
                    (
                        isset(auth()->user()->permission->sale['c_register_report']) &&
                        auth()->user()->permission->sale['c_register_report'] == '1'
                    ) ||
                    (
                        isset(auth()->user()->permission->sale['sale_representative_report']) &&
                        auth()->user()->permission->sale['sale_representative_report'] == '1'
                    )
                ): ?>
                    <li data-menu="sales" class="<?php echo e(request()->is('sales*') ? 'menu_active' : ''); ?>">
                        <a href="#">
                            <img src="<?php echo e(asset('public/backend/asset/img/icon/shopping-bag.svg')); ?>">
                            <p class="title"><?php echo app('translator')->get('menu.sales'); ?></p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(json_decode($generalSettings->modules, true)['transfer_stock'] == '1'): ?>

                    <li data-menu="transfer" class="<?php echo e(request()->is('transfer/stocks*') ? 'menu_active' : ''); ?>">
                        <a href="#">
                            <img src="<?php echo e(asset('public/backend/asset/img/icon/transfer.svg')); ?>">
                            <p class="title"><?php echo app('translator')->get('menu.transfer'); ?></p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(json_decode($generalSettings->modules, true)['stock_adjustment'] == '1'): ?>

                    <?php if(
                        auth()->user()->permission->s_adjust['adjustment_all'] == '1' ||
                        auth()->user()->permission->s_adjust['adjustment_add_from_location'] == '1' ||
                        auth()->user()->permission->s_adjust['adjustment_add_from_warehouse'] == '1' ||
                        (
                            isset(auth()->user()->permission->s_adjust['stock_adjustment_report']) &&
                            auth()->user()->permission->s_adjust['stock_adjustment_report'] == '1'
                        )
                    ): ?>
                        <li data-menu="adjustment"
                            class="<?php echo e(request()->is('stock/adjustments*') ? 'menu_active' : ''); ?>">
                            <a href="#">
                                <img src="<?php echo e(asset('public/backend/asset/img/icon/slider-tool.svg')); ?>">
                                <p class="title"><?php echo app('translator')->get('menu.adjustment'); ?></p>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if(json_decode($generalSettings->modules, true)['expenses'] == '1'): ?>

                    <?php if(
                        auth()->user()->permission->expense['view_expense'] == '1' ||
                        auth()->user()->permission->expense['add_expense'] == '1' ||
                        auth()->user()->permission->expense['expense_category'] == '1' ||
                        auth()->user()->permission->expense['category_wise_expense'] == '1' ||
                        (
                            isset(auth()->user()->permission->expense['expanse_report']) &&
                            auth()->user()->permission->expense['expanse_report'] == '1'
                        )
                    ): ?>
                        <li data-menu="expenses" class="<?php echo e(request()->is('expenses*') ? 'menu_active' : ''); ?>">
                            <a href="#">
                                <img src="<?php echo e(asset('public/backend/asset/img/icon/budget.svg')); ?>">
                                <p class="title"><?php echo app('translator')->get('menu.expenses'); ?></p>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if(json_decode($generalSettings->modules, true)['accounting'] == '1'): ?>

                    <?php if(auth()->user()->permission->accounting['ac_access'] == '1'): ?>
                        <li data-menu="accounting" class="<?php echo e(request()->is('accounting*') ? 'menu_active' : ''); ?>">
                            <a href="#">
                                <img src="<?php echo e(asset('public/backend/asset/img/icon/accounting.svg')); ?>">
                                <p class="title"><?php echo app('translator')->get('menu.accounting'); ?></p>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if(
                    auth()->user()->permission->user['user_view'] == '1' ||
                    auth()->user()->permission->user['user_add'] == '1' ||
                    auth()->user()->permission->user['role_view'] == '1' ||
                    auth()->user()->permission->user['role_add'] == '1'
                ): ?>
                    <li data-menu="users" class="<?php echo e(request()->is('users*') ? 'menu_active' : ''); ?>">
                        <a href="#">
                            <img src="<?php echo e(asset('public/backend/asset/img/icon/team.svg')); ?>">
                            <p class="title"><?php echo app('translator')->get('menu.users'); ?></p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if($addons->hrm): ?>

                    <?php if(
                        auth()->user()->permission->hrms['hrm_dashboard'] == '1' ||
                        auth()->user()->permission->hrms['leave_type'] == '1' ||
                        auth()->user()->permission->hrms['leave_assign'] == '1' ||
                        auth()->user()->permission->hrms['shift'] == '1' ||
                        auth()->user()->permission->hrms['attendance'] == '1' ||
                        auth()->user()->permission->hrms['view_allowance_and_deduction'] == '1' ||
                        auth()->user()->permission->hrms['payroll'] == '1' ||
                        auth()->user()->permission->hrms['department'] == '1' ||
                        auth()->user()->permission->hrms['designation'] == '1' ||
                        (
                            isset(auth()->user()->permission->hrms['payroll_report']) &&
                            auth()->user()->permission->hrms['payroll_report'] == '1'
                        )
                            ||
                        (
                            isset(auth()->user()->permission->hrms['payroll_payment_report']) &&
                            auth()->user()->permission->hrms['payroll_payment_report'] == '1'
                        )
                            ||
                        (
                            isset(auth()->user()->permission->hrms['attendance_report']) &&
                            auth()->user()->permission->hrms['attendance_report'] == '1'
                        )
                    ): ?>
                        <li data-menu="hrm" class="<?php echo e(request()->is('hrm*') ? 'menu_active' : ''); ?>">
                            <a href="#">
                                <img src="<?php echo e(asset('public/backend/asset/img/icon/human-resources.svg')); ?>">
                                <p class="title"><?php echo app('translator')->get('menu.hrm'); ?></p>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if($addons->manufacturing == 1): ?>

                    <?php if(
                        auth()->user()->permission->manufacturing['process_view'] == '1' ||
                        auth()->user()->permission->manufacturing['production_view'] == '1' ||
                        auth()->user()->permission->manufacturing['manuf_settings'] == '1' ||
                        auth()->user()->permission->manufacturing['manuf_report'] == '1'
                    ): ?>
                        <li data-menu="manufacture" class="<?php echo e(request()->is('manufacturing*') ? 'menu_active' : ''); ?>">
                            <a href="#">
                                <img src="<?php echo e(asset('public/backend/asset/img/icon/conveyor.svg')); ?>">
                                <p class="title"><?php echo app('translator')->get('menu.manufacturing'); ?></p>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if($addons->todo == 1): ?>

                    <?php if(json_decode($generalSettings->modules, true)['requisite'] == '1'): ?>

                        <?php if(
                            auth()->user()->permission->essential['assign_todo'] == '1' ||
                            auth()->user()->permission->essential['work_space'] == '1' ||
                            auth()->user()->permission->essential['memo'] == '1' ||
                            auth()->user()->permission->essential['msg'] == '1'
                        ): ?>
                            <li data-menu="essentials" class="<?php echo e(request()->is('essentials*') ? 'menu_active' : ''); ?>">
                                <a href="#">
                                    <img src="<?php echo e(asset('public/backend/asset/img/icon/to-do-list.svg')); ?>">
                                    <p class="title"><?php echo app('translator')->get('menu.essentials'); ?></p>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>

                

                <li data-menu="communication" class="<?php echo e(request()->is('communication*') ? 'menu_active' : ''); ?>">
                    <a href="#">
                        <img src="<?php echo e(asset('public/backend/asset/img/icon/communication.svg')); ?>">
                        <p class="title"><?php echo app('translator')->get('menu.communication'); ?></p>
                    </a>
                </li>

                <?php if(
                    auth()->user()->permission->setup['branch'] == '1' ||
                    auth()->user()->permission->setup['warehouse'] == '1' ||
                    auth()->user()->permission->setup['tax'] == '1' ||
                    auth()->user()->permission->setup['g_settings'] == '1' ||
                    auth()->user()->permission->setup['p_settings'] == '1' ||
                    auth()->user()->permission->setup['inv_sc'] == '1' ||
                    auth()->user()->permission->setup['inv_lay'] == '1' ||
                    auth()->user()->permission->setup['barcode_settings'] == '1' ||
                    auth()->user()->permission->setup['cash_counters'] == '1'
                ): ?>
                    <li data-menu="settings" class="<?php echo e(request()->is('settings*') ? 'menu_active' : ''); ?>">
                        <a href="#">
                            <img src="<?php echo e(asset('public/backend/asset/img/icon/settings.svg')); ?>">
                            <p class="title"><?php echo app('translator')->get('menu.setup'); ?></p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(
                    auth()->user()->permission->report['tax_report'] == '1'
                ): ?>
                    <li data-menu="reports" class="<?php echo e(request()->is('reports*') ? 'menu_active' : ''); ?>">
                        <a href="#">
                            <img src="<?php echo e(asset('public/backend/asset/img/icon/business-report.svg')); ?>">
                            <p class="title"><?php echo app('translator')->get('Reports'); ?></p>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>

    <div class="category-bar">
        <div id="sidebar_t">
            <div class="sub-menu_t" id="product">
                <div class="sub-menu-width">
                    <div class="model__close bg-secondary-2">
                        <div class="row">
                            <div class="col-md-8">
                                <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('Product Management'); ?></strong></p>
                            </div>
                            <div class="col-md-4">
                                <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="container-fluid">
                        <div class="row">
                            <?php if(auth()->user()->permission->product['product_add'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('products.add.view')); ?>" class="bar-link">
                                            <span>
                                                <i class="fas fa-plus-circle"></i>
                                            </span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.add_product'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->product['product_all'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('products.all.product')); ?>" class="bar-link">
                                            <span>
                                                <i class="fas fa-sitemap"></i>
                                            </span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.product_list'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->product['product_add'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('product.import.create')); ?>" class="bar-link">
                                            <span>
                                                <i class="fas fa-file-import"></i>
                                            </span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.import_products'); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <hr class="p-0 m-0 my-1">

                        <div class="row">
                            <?php if(auth()->user()->permission->product['categories'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('product.categories.index')); ?>" class="bar-link">
                                            <span>
                                                <i class="fas fa-th-large"></i>
                                            </span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.categories'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->product['brand'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('product.brands.index')); ?>" class="bar-link">
                                            <span>
                                                <i class="fas fa-band-aid"></i>
                                            </span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.brand'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->product['units'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('settings.units.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-weight-hanging"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.units'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->product['variant'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('product.variants.index')); ?>" class="bar-link">
                                            <span>
                                                <i class="fas fa-align-center"></i>
                                            </span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.variants'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->product['warranties'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('product.warranties.index')); ?>" class="bar-link">
                                            <span>
                                                <i class="fas fa-shield-alt"></i>
                                            </span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.warranties'); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <hr class="p-0 m-0 my-1">

                        <div class="row">
                            <?php if(auth()->user()->permission->product['selling_price_group'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('product.selling.price.groups.index')); ?>" class="bar-link">
                                            <span>
                                                <i class="fas fa-layer-group"></i>
                                            </span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.selling_price_group'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->product['generate_barcode'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('barcode.index')); ?>" class="bar-link">
                                            <span>
                                                <i class="fas fa-barcode"></i>
                                            </span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.generate_barcode'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(
                                isset(auth()->user()->permission->product['product_settings']) &&
                                auth()->user()->permission->product['product_settings'] == '1'
                            ): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('products.settings')); ?>" class="bar-link">
                                            <span>
                                                <i class="fas fa-sliders-h"></i>
                                            </span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.product_settings'); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <?php if(
                            (
                                isset(auth()->user()->permission->product['stock_report']) &&
                                auth()->user()->permission->product['stock_report'] == '1'
                            )
                                ||
                            (
                                isset(auth()->user()->permission->product['stock_in_out_report']) &&
                                auth()->user()->permission->product['stock_in_out_report'] == '1'
                            )
                        ): ?>
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                                    <p class="text-muted mt-1 ms-3"><strong><?php echo app('translator')->get('Product Reports'); ?></strong></p>
                                    <hr class="p-0 m-0 my-1">
                                </div>

                                <?php if(
                                    isset(auth()->user()->permission->product['stock_report']) &&
                                    auth()->user()->permission->product['stock_report'] == '1'
                                ): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('reports.stock.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-sitemap"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.stock_report'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(
                                    isset(auth()->user()->permission->product['stock_in_out_report']) &&
                                    auth()->user()->permission->product['stock_in_out_report'] == '1'
                                ): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('reports.stock.in.out.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-cubes"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.stock_in_out_report'); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if($addons->branches == 1): ?>

                <div class="sub-menu_t" id="superadmin">
                    <div class="sub-menu-width">
                        <div class="model__close bg-secondary-2">
                            <div class="row">
                                <div class="col-md-8">
                                    <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('Superadmin'); ?></strong></p>
                                </div>
                                <div class="col-md-4">
                                    <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                                </div>
                            </div>
                        </div>

                        <div class="container-fluid">
                            <div class="row">
                                <?php if(auth()->user()->permission->setup['branch'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('settings.branches.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-project-diagram"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.branches'); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(json_decode($generalSettings->modules, true)['contacts'] == '1'): ?>

                <div class="sub-menu_t" id="contact">
                    <div class="sub-menu-width">
                        <div class="model__close bg-secondary-2">
                            <div class="row">
                                <div class="col-md-8">
                                    <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('Contact Management'); ?></strong></p>
                                </div>
                                <div class="col-md-4">
                                    <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                                </div>
                            </div>
                        </div>

                        <div class="container-fluid">
                            <div class="row">
                                <?php if(auth()->user()->permission->contact['supplier_all'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('contacts.supplier.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-address-card"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.suppliers'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->contact['supplier_import'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('contacts.suppliers.import.create')); ?>" class="bar-link">
                                                <span><i class="fas fa-file-import"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.import_suppliers'); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <hr class="p-0 m-0 my-1">

                            <div class="row">
                                <?php if(auth()->user()->permission->contact['customer_all'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('contacts.customer.index')); ?>" class="bar-link">
                                                <span><i class="far fa-address-card"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.customers'); ?> </p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->contact['customer_import'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('contacts.customers.import.create')); ?>" class="bar-link">
                                                <span><i class="fas fa-file-upload"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.import_customers'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->contact['customer_group'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('contacts.customers.groups.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-users"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.customer_groups'); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if(
                                (
                                    isset(auth()->user()->permission->contact['supplier_report']) &&
                                    auth()->user()->permission->contact['supplier_report'] == '1'
                                )
                                    ||
                                (
                                    isset(auth()->user()->permission->contact['customer_report']) &&
                                    auth()->user()->permission->contact['customer_report'] == '1'
                                )
                            ): ?>
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                                        <p class="text-muted mt-1 ms-3"><strong><?php echo app('translator')->get('Contact Reports'); ?></strong></p>
                                        <hr class="p-0 m-0 my-1">
                                    </div>

                                    <?php if(
                                        isset(auth()->user()->permission->contact['supplier_report']) &&
                                        auth()->user()->permission->contact['supplier_report']
                                    ): ?>
                                        <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                            <div class="switch_bar">
                                                <a href="<?php echo e(route('reports.supplier.index')); ?>" class="bar-link">
                                                    <span><i class="fas fa-id-card"></i></span>
                                                </a>
                                            </div>
                                            <p class="switch_text"><?php echo app('translator')->get('menu.supplier_report'); ?></p>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(
                                        isset(auth()->user()->permission->contact['customer_report']) &&
                                        auth()->user()->permission->contact['customer_report']
                                    ): ?>
                                        <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                            <div class="switch_bar">
                                                <a href="<?php echo e(route('reports.customer.index')); ?>" class="bar-link">
                                                    <span><i class="far fa-id-card"></i></span>
                                                </a>
                                            </div>
                                            <p class="switch_text"><?php echo app('translator')->get('menu.customer_report'); ?></p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(json_decode($generalSettings->modules, true)['purchases'] == '1'): ?>

                <?php if(!auth()->user()->branch_id): ?>

                    <div class="sub-menu_t" id="purchases">
                        <div class="sub-menu-width">
                            <div class="model__close bg-secondary-2">
                                <div class="row">
                                    <div class="col-md-8">
                                        <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('Purchase Management'); ?></strong></p>
                                    </div>
                                    <div class="col-md-4">
                                        <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                                    </div>
                                </div>
                            </div>

                            <div class="container-fluid">
                                <div class="row">
                                    <?php if(auth()->user()->permission->purchase['purchase_add'] == '1'): ?>
                                        <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                            <div class="switch_bar">
                                                <a href="<?php echo e(route('purchases.create')); ?>" class="bar-link">
                                                    <span><i class="fas fa-shopping-cart"></i></span>
                                                </a>
                                            </div>
                                            <p class="switch_text"><?php echo app('translator')->get('menu.add_purchase'); ?></p>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(auth()->user()->permission->purchase['purchase_all'] == '1'): ?>
                                        <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                            <div class="switch_bar">
                                                <a href="<?php echo e(route('purchases.index_v2')); ?>" class="bar-link">
                                                    <span><i class="fas fa-list"></i></span>
                                                </a>
                                            </div>
                                            <p class="switch_text"><?php echo app('translator')->get('menu.purchase_list'); ?></p>
                                        </div>

                                        <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                            <div class="switch_bar">
                                                <a href="<?php echo e(route('purchases.product.list')); ?>" class="bar-link">
                                                    <span><i class="fas fa-list"></i></span>
                                                </a>
                                            </div>
                                            <p class="switch_text"><?php echo app('translator')->get('menu.purchase_product_list'); ?></p>
                                        </div>

                                        <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                            <div class="switch_bar">
                                                <a href="<?php echo e(route('purchases.po.list')); ?>" class="bar-link">
                                                    <span><i class="fas fa-list"></i></span>
                                                </a>
                                            </div>
                                            <p class="switch_text"><?php echo app('translator')->get('menu.po_list'); ?></p>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(
                                        isset(auth()->user()->permission->purchase['purchase_settings']) &&
                                        auth()->user()->permission->purchase['purchase_settings'] == '1'
                                    ): ?>
                                        <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                            <div class="switch_bar">
                                                <a href="<?php echo e(route('purchase.settings')); ?>" class="bar-link">
                                                    <span><i class="fas fa-sliders-h"></i></span>
                                                </a>
                                            </div>
                                            <p class="switch_text"><?php echo app('translator')->get('menu.purchase_settings'); ?></p>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <hr class="p-0 m-0 my-1">

                                <?php if(auth()->user()->permission->purchase['purchase_return'] == '1'): ?>
                                    <div class="row">
                                        <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                            <div class="switch_bar">
                                                <a href="<?php echo e(route('purchases.returns.supplier.return')); ?>"
                                                    class="bar-link">
                                                    <span><i class="fas fa-plus-circle"></i></span>
                                                </a>
                                            </div>
                                            <p class="switch_text"> <?php echo app('translator')->get('menu.add_return'); ?></p>
                                        </div>

                                        <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                            <div class="switch_bar">
                                                <a href="<?php echo e(route('purchases.returns.index')); ?>" class="bar-link">
                                                    <span><i class="fas fa-undo"></i></span>
                                                </a>
                                            </div>
                                            <p class="switch_text"><?php echo app('translator')->get('menu.purchase_return_list'); ?></p>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php if(
                                    (
                                        isset(auth()->user()->permission->purchase['purchase_statements']) &&
                                        auth()->user()->permission->purchase['purchase_statements'] == '1'
                                    ) ||
                                    (
                                        isset(auth()->user()->permission->purchase['purchase_sale_report']) &&
                                        auth()->user()->permission->purchase['purchase_sale_report'] == '1'
                                    ) ||
                                    (
                                        isset(auth()->user()->permission->purchase['pro_purchase_report']) &&
                                        auth()->user()->permission->purchase['pro_purchase_report'] == '1'
                                    ) ||
                                    (
                                        isset(auth()->user()->permission->purchase['purchase_payment_report']) &&
                                        auth()->user()->permission->purchase['purchase_payment_report'] == '1'
                                    )
                                ): ?>

                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                                            <p class="text-muted ms-3"><strong><?php echo app('translator')->get('Purchase Reports'); ?></strong></p>
                                            <hr class="p-0 m-0 my-1">
                                        </div>

                                        <?php if(
                                            isset(auth()->user()->permission->purchase['purchase_statements']) &&
                                            auth()->user()->permission->purchase['purchase_statements'] == '1'
                                        ): ?>
                                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                                <div class="switch_bar">
                                                    <a href="<?php echo e(route('reports.purchases.statement.index')); ?>" class="bar-link">
                                                        <span><i class="fas fa-tasks"></i></span>
                                                    </a>
                                                </div>
                                                <p class="switch_text"><?php echo app('translator')->get('menu.purchase_statements'); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <?php if(
                                            isset(auth()->user()->permission->purchase['purchase_sale_report']) &&
                                            auth()->user()->permission->purchase['purchase_sale_report'] == '1'
                                        ): ?>
                                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                                <div class="switch_bar">
                                                    <a href="<?php echo e(route('reports.sales.purchases.index')); ?>" class="bar-link">
                                                        <span><i class="far fa-chart-bar"></i></span>
                                                    </a>
                                                </div>
                                                <p class="switch_text"><?php echo app('translator')->get('menu.purchase_sale'); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <?php if(
                                            isset(auth()->user()->permission->purchase['pro_purchase_report']) &&
                                            auth()->user()->permission->purchase['pro_purchase_report'] == '1'
                                        ): ?>
                                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                                <div class="switch_bar">
                                                    <a href="<?php echo e(route('reports.product.purchases.index')); ?>" class="bar-link">
                                                        <span><i class="fas fa-shopping-cart"></i></span>
                                                    </a>
                                                </div>
                                                <p class="switch_text"><?php echo app('translator')->get('menu.product_purchase_report'); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <?php if(
                                            isset(auth()->user()->permission->purchase['purchase_payment_report']) &&
                                            auth()->user()->permission->purchase['purchase_payment_report'] == '1'
                                        ): ?>
                                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                                <div class="switch_bar">
                                                    <a href="<?php echo e(route('reports.purchase.payments.index')); ?>" class="bar-link">
                                                        <span><i class="fas fa-money-check-alt"></i></span>
                                                    </a>
                                                </div>
                                                <p class="switch_text"><?php echo app('translator')->get('menu.purchase_payment_report'); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php elseif(auth()->user()->branch_id && auth()->user()->branch->purchase_permission == 1): ?>

                    <?php if(auth()->user()->permission->purchase['purchase_all'] == '1'): ?>

                        <div class="sub-menu_t" id="purchases">
                            <div class="sub-menu-width">
                                <div class="model__close bg-secondary-2">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('Purchase Management'); ?></strong></p>
                                        </div>
                                        <div class="col-md-4">
                                            <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="container-fluid">
                                    <div class="row">
                                        <?php if(auth()->user()->permission->purchase['purchase_add'] == '1'): ?>

                                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                                <div class="switch_bar">
                                                    <a href="<?php echo e(route('purchases.create')); ?>" class="bar-link">
                                                        <span><i class="fas fa-shopping-cart"></i></span>
                                                    </a>
                                                </div>
                                                <p class="switch_text"><?php echo app('translator')->get('menu.add_purchase'); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <?php if(auth()->user()->permission->purchase['purchase_all'] == '1'): ?>

                                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                                <div class="switch_bar">
                                                    <a href="<?php echo e(route('purchases.index_v2')); ?>" class="bar-link">
                                                        <span><i class="fas fa-list"></i></span>
                                                    </a>
                                                </div>
                                                <p class="switch_text"><?php echo app('translator')->get('menu.purchase_list'); ?></p>
                                            </div>

                                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                                <div class="switch_bar">
                                                    <a href="<?php echo e(route('purchases.product.list')); ?>" class="bar-link">
                                                        <span><i class="fas fa-list"></i></span>
                                                    </a>
                                                </div>
                                                <p class="switch_text"><?php echo app('translator')->get('menu.purchase_product_list'); ?></p>
                                            </div>

                                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                                <div class="switch_bar">
                                                    <a href="<?php echo e(route('purchases.po.list')); ?>" class="bar-link">
                                                        <span><i class="fas fa-list"></i></span>
                                                    </a>
                                                </div>
                                                <p class="switch_text"><?php echo app('translator')->get('menu.po_list'); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <?php if(
                                            isset(auth()->user()->permission->purchase['purchase_settings']) &&
                                            auth()->user()->permission->purchase['purchase_settings'] == '1'
                                        ): ?>
                                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                                <div class="switch_bar">
                                                    <a href="<?php echo e(route('purchase.settings')); ?>" class="bar-link">
                                                        <span><i class="fas fa-sliders-h"></i></span>
                                                    </a>
                                                </div>
                                                <p class="switch_text"><?php echo app('translator')->get('menu.purchase_settings'); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <hr class="p-0 m-0 my-1">

                                    <div class="row">
                                        <?php if(auth()->user()->permission->purchase['purchase_return'] == '1'): ?>
                                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                                <div class="switch_bar">
                                                    <a href="<?php echo e(route('purchases.returns.supplier.return')); ?>"
                                                        class="bar-link">
                                                        <span><i class="fas fa-plus-circle"></i></span>
                                                    </a>
                                                </div>
                                                <p class="switch_text"> <?php echo app('translator')->get('menu.add_return'); ?></p>
                                            </div>

                                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                                <div class="switch_bar">
                                                    
                                                    <a href="<?php echo e(route('purchases.returns.index')); ?>"
                                                        class="bar-link">
                                                        <span><i class="fas fa-undo"></i></span>
                                                    </a>
                                                </div>
                                                <p class="switch_text"> <?php echo app('translator')->get('menu.purchase_return_list'); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <?php if(
                                        (
                                            isset(auth()->user()->permission->purchase['purchase_statements']) &&
                                            auth()->user()->permission->purchase['purchase_statements'] == '1'
                                        ) ||
                                        (
                                            isset(auth()->user()->permission->purchase['purchase_sale_report']) &&
                                            auth()->user()->permission->purchase['purchase_sale_report'] == '1'
                                        ) ||
                                        (
                                            isset(auth()->user()->permission->purchase['pro_purchase_report']) &&
                                            auth()->user()->permission->purchase['pro_purchase_report'] == '1'
                                        ) ||
                                        (
                                            isset(auth()->user()->permission->purchase['purchase_payment_report']) &&
                                            auth()->user()->permission->purchase['purchase_payment_report'] == '1'
                                        )
                                    ): ?>

                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                                                <p class="text-muted ms-3"><strong><?php echo app('translator')->get('Purchase Reports'); ?></strong></p>
                                                <hr class="p-0 m-0 my-1">
                                            </div>

                                            <?php if(
                                                isset(auth()->user()->permission->purchase['purchase_statements']) &&
                                                auth()->user()->permission->purchase['purchase_statements'] == '1'
                                            ): ?>
                                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                                    <div class="switch_bar">
                                                        <a href="<?php echo e(route('reports.purchases.statement.index')); ?>" class="bar-link">
                                                            <span><i class="fas fa-tasks"></i></span>
                                                        </a>
                                                    </div>
                                                    <p class="switch_text"><?php echo app('translator')->get('menu.purchase_statements'); ?></p>
                                                </div>
                                            <?php endif; ?>

                                            <?php if(
                                                isset(auth()->user()->permission->purchase['purchase_sale_report']) &&
                                                auth()->user()->permission->purchase['purchase_sale_report'] == '1'
                                            ): ?>
                                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                                    <div class="switch_bar">
                                                        <a href="<?php echo e(route('reports.sales.purchases.index')); ?>" class="bar-link">
                                                            <span><i class="far fa-chart-bar"></i></span>
                                                        </a>
                                                    </div>
                                                    <p class="switch_text"><?php echo app('translator')->get('menu.purchase_sale'); ?></p>
                                                </div>
                                            <?php endif; ?>

                                            <?php if(
                                                isset(auth()->user()->permission->purchase['pro_purchase_report']) &&
                                                auth()->user()->permission->purchase['pro_purchase_report'] == '1'
                                            ): ?>
                                                <div
                                                    class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                                    <div class="switch_bar">
                                                        <a href="<?php echo e(route('reports.product.purchases.index')); ?>" class="bar-link">
                                                            <span><i class="fas fa-shopping-cart"></i></span>
                                                        </a>
                                                    </div>
                                                    <p class="switch_text"><?php echo app('translator')->get('menu.product_purchase_report'); ?></p>
                                                </div>
                                            <?php endif; ?>

                                            <?php if(
                                                isset(auth()->user()->permission->purchase['purchase_payment_report']) &&
                                                auth()->user()->permission->purchase['purchase_payment_report'] == '1'
                                            ): ?>
                                                <div
                                                    class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                                    <div class="switch_bar">
                                                        <a href="<?php echo e(route('reports.purchase.payments.index')); ?>" class="bar-link">
                                                            <span><i class="fas fa-money-check-alt"></i></span>
                                                        </a>
                                                    </div>
                                                    <p class="switch_text"><?php echo app('translator')->get('menu.purchase_payment_report'); ?></p>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                <?php endif; ?>
            <?php endif; ?>

            <div class="sub-menu_t" id="sales">
                <div class="sub-menu-width">
                    <div class="model__close bg-secondary-2">
                        <div class="row">
                            <div class="col-md-8">
                                <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('Sale Management'); ?></strong></p>
                            </div>
                            <div class="col-md-4">
                                <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="container-fluid">
                        <div class="row">

                            <?php if(json_decode($generalSettings->modules, true)['add_sale'] == '1'): ?>

                                <?php if(auth()->user()->permission->sale['create_add_sale']): ?>

                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('sales.create')); ?>" class="bar-link">
                                                <span><i class="fas fa-cart-plus"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"> <?php echo app('translator')->get('menu.add_sale'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->sale['view_add_sale']): ?>

                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('sales.index2')); ?>" class="bar-link">
                                                <span><i class="fas fa-tasks"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.add_sale_list'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(
                                    isset(auth()->user()->permission->sale['add_sale_settings']) &&
                                    auth()->user()->permission->sale['add_sale_settings'] == '1'
                                ): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('sales.add.sale.settings')); ?>" class="bar-link">
                                                <span><i class="fas fa-sliders-h"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.add_sale_settings'); ?></p>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <hr class="p-0 m-0 my-1">

                        <div class="row">
                            <?php if(json_decode($generalSettings->modules, true)['pos'] == '1'): ?>

                                <?php if(auth()->user()->permission->sale['pos_add'] == '1'): ?>

                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('sales.pos.create')); ?>" class="bar-link">
                                                <span><i class="fas fa-cash-register"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.pos'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->sale['pos_all'] == '1'): ?>

                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('sales.pos.list')); ?>" class="bar-link">
                                                <span><i class="fas fa-tasks"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.pos_sale_list'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(
                                    isset(auth()->user()->permission->sale['pos_sale_settings']) &&
                                    auth()->user()->permission->sale['pos_sale_settings'] == '1'
                                ): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('sales.pos.settings')); ?>" class="bar-link">
                                                <span><i class="fas fa-sliders-h"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.pos_sale_settings'); ?></p>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <hr class="p-0 m-0 my-1">

                        <div class="row">
                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                <div class="switch_bar">
                                    <a href="<?php echo e(route('sales.order.list')); ?>" class="bar-link">
                                        <span><i class="fa fa-file-alt"></i></span>
                                    </a>
                                </div>
                                <p class="switch_text"><?php echo app('translator')->get('menu.sales_order_list'); ?></p>
                            </div>

                            <?php if(auth()->user()->permission->sale['sale_draft'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('sales.drafts')); ?>" class="bar-link">
                                            <span><i class="fas fa-drafting-compass"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.draft_list'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->sale['sale_quotation'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('sales.quotations')); ?>" class="bar-link">
                                            <span><i class="fas fa-quote-right"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.quotation_list'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(
                                auth()->user()->permission->sale['view_add_sale'] ||
                                auth()->user()->permission->sale['pos_all']
                            ): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('sales.product.list')); ?>" class="bar-link">
                                            <span><i class="fas fa-tasks"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.sold_product_list'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->sale['shipment_access'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('sales.shipments')); ?>" class="bar-link">
                                            <span><i class="fas fa-shipping-fast"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.shipments'); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <hr class="p-0 m-0 my-1">

                        <div class="row">
                            <?php if(auth()->user()->permission->sale['return_access'] == '1'): ?>

                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('sale.return.random.create')); ?>" class="bar-link">
                                            <span><i class="fas fa-undo"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.add_sale_return'); ?></p>
                                </div>

                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('sales.returns.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-undo"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.sale_return_list'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(
                                isset(auth()->user()->permission->sale['discounts']) &&
                                auth()->user()->permission->sale['discounts'] == '1'
                            ): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('sales.discounts.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-percentage"></i></span>
                                        </a>
                                    </div>

                                    <p class="switch_text"><?php echo app('translator')->get('menu.discounts'); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <?php if(
                            (
                                isset(auth()->user()->permission->sale['pro_sale_report']) &&
                                auth()->user()->permission->sale['pro_sale_report'] == '1'
                            ) ||
                            (
                                isset(auth()->user()->permission->sale['sale_payment_report']) &&
                                auth()->user()->permission->sale['sale_payment_report'] == '1'
                            ) ||
                            (
                                isset(auth()->user()->permission->sale['c_register_report']) &&
                                auth()->user()->permission->sale['c_register_report'] == '1'
                            ) ||
                            (
                                isset(auth()->user()->permission->sale['sale_representative_report']) &&
                                auth()->user()->permission->sale['sale_representative_report'] == '1'
                            )
                        ): ?>
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                                    <p class="text-muted mt-1 ms-3"><strong><?php echo app('translator')->get('Sale Reports'); ?></strong></p>
                                    <hr class="p-0 m-0 my-1">
                                </div>

                                <?php if(
                                    isset(auth()->user()->permission->sale['sale_statements']) &&
                                    auth()->user()->permission->sale['sale_statements'] == '1'
                                ): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('reports.sale.statement.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-tasks"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.sale_statement'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(
                                    isset(auth()->user()->permission->sale['sale_return_statements']) &&
                                    auth()->user()->permission->sale['sale_return_statements'] == '1'
                                ): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('reports.sale.return.statement.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-tasks"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.return_statement'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(
                                    isset(auth()->user()->permission->sale['pro_sale_report']) &&
                                    auth()->user()->permission->sale['pro_sale_report'] == '1'
                                ): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('reports.product.sales.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-cart-arrow-down"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.product_sale_report'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(
                                    isset(auth()->user()->permission->sale['sale_payment_report']) &&
                                    auth()->user()->permission->sale['sale_payment_report'] == '1'
                                ): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('reports.sale.payments.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-hand-holding-usd"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.sale_payment_report'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(
                                    isset(auth()->user()->permission->sale['c_register_report']) &&
                                    auth()->user()->permission->sale['c_register_report'] == '1'
                                ): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('reports.cash.registers.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-cash-register"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.register_report'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(
                                    isset(auth()->user()->permission->sale['sale_representative_report']) &&
                                    auth()->user()->permission->sale['sale_representative_report'] == '1'
                                ): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('reports.sale.representive.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-user-tie"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.sales_representative_report'); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if(json_decode($generalSettings->modules, true)['transfer_stock'] == '1'): ?>
                <div class="sub-menu_t" id="transfer">
                    <div class="sub-menu-width">
                        <div class="model__close bg-secondary-2">
                            <div class="row">
                                <div class="col-md-8">
                                    <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('Stock Transfer Management'); ?></strong></p>
                                </div>
                                <div class="col-md-4">
                                    <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                                </div>
                            </div>
                        </div>
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-10 p-1 ms-4 text-center d-flex justify-content-top align-items-start flex-column">
                                    <p><?php echo __('menu.transfer_stock_heading_1'); ?></p>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('transfer.stock.to.branch.create')); ?>"
                                            class="bar-link"> <span><i class="fas fa-exchange-alt"></i></span>
                                        </a>
                                    </div>

                                    <p class="switch_text"><?php echo app('translator')->get('menu.add_transfer'); ?>
                                        <small class="ml-1"><b>(<?php echo app('translator')->get('menu.to_branch'); ?>)</small></b>
                                    </p>
                                </div>

                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('transfer.stock.to.branch.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-list-ul"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.transfer_list'); ?></p>
                                </div>

                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('transfer.stocks.to.warehouse.receive.stock.index')); ?>"
                                            class="bar-link">
                                            <span><i class="fas fa-check-double"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.receive_stocks'); ?>
                                        <small class="ml-1"><b>(From <?php echo app('translator')->get('B.Location'); ?>)</small></b>
                                    </p>
                                </div>
                            </div>

                            <hr class="p-0 m-0 my-1">

                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-10 p-1 ms-4 text-center d-flex justify-content-top align-items-start flex-column">
                                    <p><?php echo __('menu.transfer_stock_heading_2'); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('transfer.stock.to.warehouse.create')); ?>" class="bar-link">
                                            <span><i class="fas fa-exchange-alt"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.add_transfer'); ?>
                                        <small class="ml-1">(<?php echo app('translator')->get('menu.to_warehouse'); ?>)</small></p>
                                </div>

                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('transfer.stock.to.warehouse.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-list-ul"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.transfer_list'); ?>
                                        <small class="ml-1">(<?php echo app('translator')->get('menu.to_warehouse'); ?>)</small>
                                    </p>
                                </div>

                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('transfer.stocks.to.branch.receive.stock.index')); ?>"
                                            class="bar-link">
                                            <span><i class="fas fa-check-double"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.receive_stocks'); ?></p>
                                </div>
                            </div>

                            <?php if($addons->branches == 1): ?>
                                <hr class="p-0 m-0 my-1">
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-10 p-1 ms-4 text-center d-flex justify-content-top align-items-start flex-column">
                                        <p><?php echo __('menu.transfer_stock_heading_3'); ?></p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('transfer.stock.branch.to.branch.create')); ?>" class="bar-link">
                                                <span><i class="fas fa-exchange-alt"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.add_transfer'); ?></p>
                                    </div>

                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('transfer.stock.branch.to.branch.transfer.list')); ?>" class="bar-link">
                                                <span><i class="fas fa-list-ul"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.transfer_list'); ?></p>
                                    </div>

                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('transfer.stock.branch.to.branch.receivable.list')); ?>"
                                                class="bar-link">
                                                <span><i class="fas fa-check-double"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.receive_stocks'); ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(json_decode($generalSettings->modules, true)['stock_adjustment'] == '1'): ?>
                <div class="sub-menu_t" id="adjustment">
                    <div class="sub-menu-width">
                        <div class="model__close bg-secondary-2">
                            <div class="row">
                                <div class="col-md-8">
                                    <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('Stock Adjustment'); ?></strong></p>
                                </div>

                                <div class="col-md-4">
                                    <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                                </div>
                            </div>
                        </div>

                        <div class="container-fluid">
                            <div class="row">
                                <?php if(auth()->user()->permission->s_adjust['adjustment_add_from_location'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('stock.adjustments.create')); ?>" class="bar-link">
                                                <span><i class="fas fa-plus-square"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.add_stock_adjustment_from_branch'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->s_adjust['adjustment_add_from_warehouse'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('stock.adjustments.create.from.warehouse')); ?>" class="bar-link">
                                                <span><i class="fas fa-plus-square"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.add_stock_adjustment_from_warehouse'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->s_adjust['adjustment_add_from_location'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('stock.adjustments.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-th-list"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.stock_adjustment_list'); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if(
                                (
                                    isset(auth()->user()->permission->s_adjust['stock_adjustment_report']) &&
                                    auth()->user()->permission->s_adjust['stock_adjustment_report'] == '1'
                                )
                            ): ?>
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                                        <p class="text-muted mt-1 ms-3"><strong><?php echo app('translator')->get('Stock Adjustment Reports'); ?></strong></p>
                                        <hr class="p-0 m-0 my-1">
                                    </div>

                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('reports.stock.adjustments.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-sliders-h"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.stock_adjustment_report'); ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(json_decode($generalSettings->modules, true)['expenses'] == '1'): ?>
                <div class="sub-menu_t" id="expenses">
                    <div class="sub-menu-width">
                        <div class="model__close bg-secondary-2">
                            <div class="row">
                                <div class="col-md-8">
                                    <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('Expense Management'); ?></strong></p>
                                </div>
                                <div class="col-md-4">
                                    <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                                </div>
                            </div>
                        </div>

                        <div class="container-fluid">
                            <div class="row">
                                <?php if(auth()->user()->permission->expense['add_expense'] == '1' ): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('expanses.create')); ?>" class="bar-link">
                                                <span><i class="fas fa-plus-square"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.add_expense'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->expense['expense_category'] == '1' ): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('expanses.categories.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-cubes"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.expense_categories'); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <hr class="p-0 m-0 my-1">

                            <div class="row">
                                <?php if(auth()->user()->permission->expense['view_expense'] == '1' ): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('expanses.index')); ?>" class="bar-link">
                                                <span><i class="far fa-list-alt"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.expense_list'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->expense['category_wise_expense'] == '1' ): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('expanses.category.wise.expense')); ?>" class="bar-link">
                                                <span><i class="far fa-list-alt"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.category_wise_expenses'); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php if(
                                (
                                    isset(auth()->user()->permission->expense['expanse_report']) &&
                                    auth()->user()->permission->expense['expanse_report'] == '1'
                                )
                            ): ?>
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                                        <p class="text-muted mt-1 ms-3"><strong><?php echo app('translator')->get('Expense Reports'); ?></strong></p>
                                        <hr class="p-0 m-0 my-1">
                                    </div>

                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('reports.expenses.index')); ?>" class="bar-link">
                                                <span><i class="far fa-money-bill-alt"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.expense_report'); ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(json_decode($generalSettings->modules, true)['accounting'] == '1'): ?>

                <?php if(auth()->user()->permission->accounting['ac_access'] == 1): ?>

                    <div class="sub-menu_t" id="accounting">
                        <div class="sub-menu-width">
                            <div class="model__close bg-secondary-2">
                                <div class="row">
                                    <div class="col-md-8">
                                        <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('Account Management'); ?></strong></p>
                                    </div>
                                    <div class="col-md-4">
                                        <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                                    </div>
                                </div>
                            </div>

                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('accounting.banks.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-university"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.bank'); ?></p>
                                    </div>

                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('accounting.accounts.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-money-check-alt"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.accounts'); ?></p>
                                    </div>
                                </div>

                                <hr class="p-0 m-0 my-1">

                                <div class="row">
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('accounting.assets.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-luggage-cart"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.assets'); ?></p>
                                    </div>

                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('accounting.loan.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-hand-holding-usd"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.loans'); ?></p>
                                    </div>

                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('accounting.contras.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-hand-holding-usd"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.contra'); ?></p>
                                    </div>
                                </div>

                                <hr class="p-0 m-0 my-1">

                                <div class="row">
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('accounting.balance.sheet')); ?>" class="bar-link">
                                                <span><i class="fas fa-balance-scale"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.balance_sheet'); ?></p>
                                    </div>

                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('accounting.trial.balance')); ?>" class="bar-link">
                                                <span><i class="fas fa-balance-scale-right"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.trial_balance'); ?></p>
                                    </div>

                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('accounting.cash.flow')); ?>" class="bar-link">
                                                <span><i class="fas fa-money-bill-wave"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.cash_flow'); ?></p>
                                    </div>

                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('accounting.profit.loss.account')); ?>" class="bar-link">
                                                <span><i class="fas fa-chart-line"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.profit_loss_account'); ?></p>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                                        <p class="text-muted mt-1 ms-3"><strong><?php echo app('translator')->get('Account Reports'); ?></strong></p>
                                        <hr class="p-0 m-0 my-1">
                                    </div>

                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('reports.profit.loss.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-chart-line"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.profit_loss'); ?></p>
                                    </div>

                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('reports.financial.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-money-bill-wave"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.financial_report'); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <div class="sub-menu_t" id="users">
                <div class="sub-menu-width">
                    <div class="model__close bg-secondary-2">
                        <div class="row">
                            <div class="col-md-8">
                                <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('User Management'); ?></strong></p>
                            </div>
                            <div class="col-md-4">
                                <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="container-fluid">
                        <div class="row">
                            <?php if(auth()->user()->permission->user['user_add'] == '1'): ?>
                                <div
                                    class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('users.create')); ?>" class="bar-link">
                                            <span><i class="fas fa-user-plus"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.add_user'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->user['user_view'] == '1'): ?>
                                <div
                                    class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('users.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-list-ol"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.user_list'); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <hr class="p-0 m-0 my-1">

                        <div class="row">
                            <?php if(auth()->user()->permission->user['role_add'] == '1'): ?>
                                <div
                                    class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('users.role.create')); ?>" class="bar-link">
                                            <span><i class="fas fa-plus-circle"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.add_role'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->user['role_view'] == '1'): ?>
                                <div
                                    class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('users.role.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-th-list"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.role_list'); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <hr class="p-0 m-0 my-1">

                    </div>
                </div>
            </div>

            <?php if($addons->hrm == 1): ?>
                <div class="sub-menu_t" id="hrm">
                    <div class="sub-menu-width">
                        <div class="model__close bg-secondary-2">
                            <div class="row">
                                <div class="col-md-8">
                                    <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('Human Resource Management System'); ?></strong></p>
                                </div>

                                <div class="col-md-4">
                                    <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                                </div>
                            </div>
                        </div>

                        <div class="container-fluid">
                            <div class="row">
                                <?php if( auth()->user()->permission->hrms['hrm_dashboard'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('hrm.dashboard.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-tachometer-alt"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.hrm_dashboard'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->hrms['leave_type'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('hrm.leave.type')); ?>" class="bar-link">
                                                <span><i class="fas fa-th-large"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.leave_type'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->hrms['leave_assign'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('hrm.leave')); ?>" class="bar-link">
                                                <span><i class="fas fa-level-down-alt"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.leave'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->hrms['shift'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('hrm.attendance.shift')); ?>" class="bar-link">
                                                <span><i class="fas fa-network-wired"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.shift'); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <hr class="p-0 m-0 my-1">

                            <div class="row">
                                <?php if(auth()->user()->permission->hrms['attendance'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('hrm.attendance')); ?>" class="bar-link">
                                                <span><i class="fas fa-paste"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.attendance'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->hrms['view_allowance_and_deduction'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('hrm.allowance')); ?>" class="bar-link">
                                                <span><i class="fas fa-plus"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.allowance_deduction'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->hrms['payroll'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('hrm.payroll.index')); ?>" class="bar-link">
                                                <span><i class="far fa-money-bill-alt"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.payroll'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->hrms['holiday'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('hrm.holidays')); ?>" class="bar-link">
                                                <span><i class="fas fa-toggle-off"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.holiday'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->hrms['department'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('hrm.departments')); ?>" class="bar-link">
                                                <span><i class="far fa-building"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.department'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->hrms['designation'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('hrm.designations')); ?>" class="bar-link">
                                                <span><i class="fas fa-map-marker-alt"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.designation'); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if(
                                (
                                    isset(auth()->user()->permission->hrms['payroll_report']) &&
                                    auth()->user()->permission->hrms['payroll_report'] == '1'
                                )
                                    ||
                                (
                                    isset(auth()->user()->permission->hrms['payroll_payment_report']) &&
                                    auth()->user()->permission->hrms['payroll_payment_report'] == '1'
                                )
                                    ||
                                (
                                    isset(auth()->user()->permission->hrms['attendance_report']) &&
                                    auth()->user()->permission->hrms['attendance_report'] == '1'
                                )
                            ): ?>
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                                        <p class="text-muted mt-1 ms-3"><strong><?php echo app('translator')->get('HRM Reports'); ?></strong></p>
                                        <hr class="p-0 m-0 my-1">
                                    </div>

                                    <?php if(
                                        isset(auth()->user()->permission->hrms['payroll_report']) &&
                                        auth()->user()->permission->hrms['payroll_report'] == '1'
                                    ): ?>
                                        <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                            <div class="switch_bar">
                                                <a href="<?php echo e(route('reports.payroll')); ?>" class="bar-link">
                                                    <span><i class="fas fa-money-bill-alt"></i></span>
                                                </a>
                                            </div>
                                            <p class="switch_text"><?php echo app('translator')->get('menu.payroll_report'); ?></p>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(
                                        isset(auth()->user()->permission->hrms['payroll_payment_report']) &&
                                        auth()->user()->permission->hrms['payroll_payment_report'] == '1'
                                    ): ?>
                                        <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                            <div class="switch_bar">
                                                <a href="<?php echo e(route('reports.payroll.payment')); ?>" class="bar-link">
                                                    <span><i class="fas fa-money-bill-alt"></i></span>
                                                </a>
                                            </div>
                                            <p class="switch_text"><?php echo app('translator')->get('menu.payroll_payment_report'); ?></p>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(
                                        isset(auth()->user()->permission->hrms['attendance_report']) &&
                                        auth()->user()->permission->hrms['attendance_report'] == '1'
                                    ): ?>
                                        <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                            <div class="switch_bar">
                                                <a href="<?php echo e(route('reports.attendance')); ?>" class="bar-link">
                                                    <span><i class="fas fa-paste"></i></span>
                                                </a>
                                            </div>
                                            <p class="switch_text"><?php echo app('translator')->get('menu.attendance_report'); ?></p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="sub-menu_t" id="settings">
                <div class="sub-menu-width">
                    <div class="model__close bg-secondary-2">
                        <div class="row">
                            <div class="col-md-8">
                                <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('Set-up'); ?></strong></p>
                            </div>
                            <div class="col-md-4">
                                <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="container-fluid">
                        <div class="row">
                            <?php if(auth()->user()->permission->setup['g_settings'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('settings.general.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-cogs"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.general_settings'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if($addons->branches == 1): ?>
                                <?php if(auth()->user()->permission->setup['branch'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('settings.branches.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-project-diagram"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.branches'); ?></p>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->setup['warehouse'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('settings.warehouses.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-warehouse"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.warehouses'); ?> </p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->setup['tax'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('settings.taxes.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-percentage"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.taxes'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->setup['p_settings'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('settings.payment.method.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-credit-card"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.payment_methods'); ?></p>
                                </div>

                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('settings.payment.method.settings.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-credit-card"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.payment_method_settings'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->setup['inv_sc'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('invoices.schemas.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-file-invoice-dollar"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.invoice_schema'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->setup['inv_lay'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('invoices.layouts.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-file-invoice"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.invoice_layout'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->setup['barcode_settings'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('settings.barcode.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-barcode"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.barcode_settings'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->setup['cash_counters'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('settings.cash.counter.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-store"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.cash_counter'); ?></p>
                                </div>
                            <?php endif; ?>

                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                <div class="switch_bar">
                                    <a href="<?php echo e(route('settings.release.note.index')); ?>" class="bar-link">
                                        <span><i class="far fa-arrow-alt-circle-up"></i></span>
                                    </a>
                                </div>
                                <p class="switch_text"><?php echo app('translator')->get('Version Release Notes'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php if($addons->manufacturing == 1): ?>
                <div class="sub-menu_t" id="manufacture">
                    <div class="sub-menu-width">
                        <div class="model__close bg-secondary-2">
                            <div class="row">
                                <div class="col-md-8">
                                    <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('Manufacturing'); ?></strong></p>
                                </div>
                                <div class="col-md-4">
                                    <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                                </div>
                            </div>
                        </div>

                        <div class="container-fluid">
                            <div class="row">
                                <?php if(auth()->user()->permission->manufacturing['process_view'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('manufacturing.process.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-dumpster-fire"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.process'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->manufacturing['production_view'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('manufacturing.productions.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-shapes"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.productions'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->manufacturing['manuf_settings'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('manufacturing.settings.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-sliders-h"></i></span>
                                            </a>
                                        </div>
                                       <p class="switch_text"><?php echo app('translator')->get('menu.manufacturing_setting'); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->permission->manufacturing['manuf_report'] == '1'): ?>
                                    <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column flex-column">
                                        <div class="switch_bar">
                                            <a href="<?php echo e(route('manufacturing.report.index')); ?>" class="bar-link">
                                                <span><i class="fas fa-file-alt"></i></span>
                                            </a>
                                        </div>
                                        <p class="switch_text"><?php echo app('translator')->get('menu.manufacturing_report'); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="sub-menu_t" id="essentials">
                <div class="sub-menu-width">
                    <div class="model__close bg-secondary-2">
                        <div class="row">
                            <div class="col-md-8">
                                <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('Task Management'); ?></strong></p>
                            </div>
                            <div class="col-md-4">
                                <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="container-fluid">
                        <div class="row">
                            <?php if(auth()->user()->permission->essential['assign_todo'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('todo.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-th-list"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.todo'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->essential['work_space'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('workspace.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-th-large"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.work_space'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->essential['memo'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('memos.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-file-alt"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.memo'); ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if(auth()->user()->permission->essential['msg'] == '1'): ?>
                                <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('messages.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-envelope"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.message'); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="sub-menu_t" id="communication">
                <div class="sub-menu-width">
                    <div class="model__close bg-secondary-2">
                        <div class="row">
                            <div class="col-md-8">
                                <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('Communication'); ?></strong></p>
                            </div>

                            <div class="col-md-4">
                                <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                <div class="switch_bar">
                                    <a href="" class="bar-link">
                                        <span><i class="fas fa-exclamation"></i></span>
                                    </a>
                                </div>
                                <p class="switch_text"><?php echo app('translator')->get('menu.notice_board'); ?></p>
                            </div>
                        </div>
                        <hr class="p-0 m-0 my-1">
                        <div class="row">
                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                <div class="switch_bar">
                                    <a href="" class="bar-link">
                                        <span><i class="far fa-envelope"></i></span>
                                    </a>
                                </div>
                                <p class="switch_text"><?php echo app('translator')->get('menu.email'); ?></p>
                            </div>

                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                <div class="switch_bar">
                                    <a href="<?php echo e(route('communication.email.settings')); ?>" class="bar-link">
                                        <span><i class="fas fa-sliders-h"></i></span>
                                    </a>
                                </div>
                                <p class="switch_text"><?php echo app('translator')->get('menu.email_settings'); ?></p>
                            </div>
                        </div>
                        <hr class="p-0 m-0 my-1">
                        <div class="row">
                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                <div class="switch_bar">
                                    <a href="" class="bar-link">
                                        <span><i class="fas fa-sms"></i></span>
                                    </a>
                                </div>
                                <p class="switch_text"><?php echo app('translator')->get('menu.sms'); ?></p>
                            </div>

                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                <div class="switch_bar">
                                    <a href="<?php echo e(route('communication.sms.settings')); ?>" class="bar-link">
                                        <span><i class="fas fa-sliders-h"></i></span>
                                    </a>
                                </div>
                                <p class="switch_text"><?php echo app('translator')->get('menu.sms_settings'); ?></p>
                            </div>
                        </div>
                        <hr class="p-0 m-0 my-1">
                    </div>
                </div>
            </div>

            <div class="sub-menu_t" id="reports">
                <div class="sub-menu-width">
                    <div class="model__close bg-secondary-2">
                        <div class="row">
                            <div class="col-md-8">
                                <p class="text-muted float-start mt-1"><strong><?php echo app('translator')->get('Common Reports'); ?></strong></p>
                            </div>

                            <div class="col-md-4">
                                <a href="#" class="btn text-white btn-sm btn-info close-model float-end"><i class="fas fa-long-arrow-alt-left text-white"></i> <?php echo app('translator')->get('menu.close'); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="container-fluid">
                        <div class="row">
                            <?php if(auth()->user()->permission->report['tax_report'] == '1'): ?>
                                <div
                                    class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                    <div class="switch_bar">
                                        <a href="<?php echo e(route('reports.taxes.index')); ?>" class="bar-link">
                                            <span><i class="fas fa-percent"></i></span>
                                        </a>
                                    </div>
                                    <p class="switch_text"><?php echo app('translator')->get('menu.tax_report'); ?></p>
                                </div>
                            <?php endif; ?>

                            <div class="col-lg-1 col-md-2 col-sm-2 col-4 p-1 ms-4 text-center d-flex justify-content-top align-items-center flex-column">
                                <div class="switch_bar">
                                    <a href="<?php echo e(route('reports.user.activities.log.index')); ?>" class="bar-link">
                                        <span><i class="fa fa-clipboard-list"></i></span>
                                    </a>
                                </div>
                                <p class="switch_text"><?php echo app('translator')->get('menu.user_activities_log'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Bileet\Meta\meta-pos\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>