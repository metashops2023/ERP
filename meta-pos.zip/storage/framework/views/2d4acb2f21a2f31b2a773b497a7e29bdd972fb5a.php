<form id="add_pos_shortcut_menu" action="<?php echo e(route('pos.short.menus.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="menu-list-area">
            <ul class="list-unstyled">
                <?php $__currentLoopData = $posShortMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $smu = DB::table('pos_short_menu_users')
                        ->where('short_menu_id', $sm->id)
                        ->where('user_id', auth()->user()->id)->first(['user_id']);
                    ?>
                    <li>
                        <p><input name="menu_ids[]" <?php echo e($smu ? 'CHECKED' : ''); ?> type="checkbox" value="<?php echo e($sm->id); ?>" id="check_menu">
                            <i class="<?php echo e($sm->icon); ?> text-primary s-menu-icon ms-1"></i> <span class="s-menu-text"><?php echo e($sm->name); ?></span>
                        </p>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</form>
<?php /**PATH C:\Bileet\Meta\meta-pos\resources\views/sales/pos/ajax_view/short-menu-modal-form.blade.php ENDPATH**/ ?>