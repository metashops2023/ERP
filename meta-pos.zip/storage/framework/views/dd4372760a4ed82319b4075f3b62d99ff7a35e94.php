<?php $__currentLoopData = $shortMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="switch_bar">
        <a href="<?php echo e(route($sm->url)); ?>" class="bar-link">
            <span><i class="<?php echo e($sm->icon); ?>"></i></span>
            <p><?php echo e($sm->name); ?></p>
        </a>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="switch_bar">
    <a href="<?php echo e(route('short.menus.modal.form')); ?>" class="bar-link" id="addShortcutBtn">
        <span><i class="fas fa-plus-square text-success"></i></span>
        <p><?php echo app('translator')->get('Add Shortcut'); ?></p>
    </a>
</div>
<?php /**PATH C:\Bileet\Meta\meta-pos\resources\views/dashboard/ajax_view/switch_bar_cards.blade.php ENDPATH**/ ?>