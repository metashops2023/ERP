<table class="display data_tbl data__table">
    <thead>
        <tr>
            <th class="text-start">SL</th>
            <th class="text-start"><?php echo app('translator')->get('Bank Name'); ?></th>
            <th class="text-start"><?php echo app('translator')->get('Branch Name'); ?></th>
            <th class="text-start"><?php echo app('translator')->get('Address'); ?></th>
            <th class="text-start"><?php echo app('translator')->get('Action'); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr data-info="<?php echo e($bank); ?>">
                <td class="text-start"><?php echo e($loop->index + 1); ?></td>
                <td class="text-start"><?php echo e($bank->name); ?></td>
                <td class="text-start"><?php echo e($bank->branch_name); ?></td>
                <td class="text-start"><?php echo e($bank->address); ?></td>
                <td class="text-start">
                    <div class="dropdown table-dropdown">
                        <a href="javascript:;" id="edit" title="Edit details" class="action-btn c-edit" id="edit"><span class="fas fa-edit"></span></a>
                        <a href="<?php echo e(route('accounting.banks.delete', $bank->id)); ?>" class="action-btn c-delete" id="delete"><span class="fas fa-trash "></span></a>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<script>
    $('.data_tbl').DataTable({
        dom: "lBfrtip",
        buttons: [
            {extend: 'excel',text: 'Excel',className: 'btn btn-primary',exportOptions: {columns: 'th:not(:last-child)'}},
            {extend: 'pdf',text: 'Pdf',className: 'btn btn-primary',exportOptions: {columns: 'th:not(:last-child)'}},
            {extend: 'print',text: '<?php echo app('translator')->get("Print"); ?>',className: 'btn btn-primary',exportOptions: {columns: 'th:not(:last-child)'}},
        ],
        "lengthMenu": [[50, 100, 500, 1000, -1], [50, 100, 500, 1000, "All"]],
    });
</script>
<?php /**PATH C:\Bileet\Meta\meta-pos\resources\views/accounting/banks/ajax_view/bank_list.blade.php ENDPATH**/ ?>